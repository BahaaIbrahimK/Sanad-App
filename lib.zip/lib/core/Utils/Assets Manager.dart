class AssetsManager {
  AssetsManager._();

  // Folders
  static const _assetsFolder = 'assets';
  static const translationsFolder = '$_assetsFolder/translations';
  static const _imagesFolder = '$_assetsFolder/images';

  static const traffic_gif =  '$_imagesFolder/traffic_gif.gif';


}