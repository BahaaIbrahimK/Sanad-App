import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../Core/Utils/App Colors.dart';
import '../../../../../core/Utils/signoutMessage.dart';
import '../../../../Moderator Role Type/Beneficiary Details/presenation/view/notifications_view.dart';
import '../../../Assessment/presenation/view/assessment_view.dart';
import '../../../Monthly_Balance/presenation/view/monthly_balance_view.dart';
import '../../../NeedsOrders/presenation/view/needs_orders_view.dart';
import '../../../Profile/presenation/view/Profile_view.dart';
import '../../../Reports/presentation/view/Report.dart';


class DocumentsScreen extends StatefulWidget {
  const DocumentsScreen({super.key});

  @override
  _DocumentsScreenState createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  Color _uploadItemColor = Colors.white; // Default background color for upload items
  Color _downloadItemColor = Colors.white; // Default background color for download items

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _animation = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(color: Colors.white),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    PopupMenuButton<String>(
                      icon: Icon(Icons.menu, size: 30, color: Colors.green[700]),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      color: Colors.green[700],
                      elevation: 8,
                      itemBuilder: (BuildContext context) => [
                        _buildMenuItem("الملف الشخصي", "profile", Icons.person),
                        _buildMenuItem("تقييم الحالة", "assessment", Icons.assessment),
                        _buildMenuItem("المحفظه الماليه", "balance", Icons.account_balance_wallet),
                        _buildMenuItem("شركاء النجاح", "request_aid", Icons.help_outline),
                        _buildMenuItem("الاشعارات", "notification", Icons.notifications),
                        _buildMenuItem("الوثائق", "documents", Icons.file_copy_rounded),
                        _buildMenuItem("تقارير المساعده الشهريه", "reports", Icons.monetization_on),
                        _buildMenuItem("تسجيل الخروج", "signout", Icons.logout),
                      ],
                      onSelected: _handleMenuSelection,
                    ),
                    Image.asset(
                      "assets/images/logo.png", // Replace with your logo path
                      height: 50,
                      fit: BoxFit.contain,
                    ),
                  ],
                ),
              ),

              // Content Section
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: ListView(
                    children: [
                      const SizedBox(height: 24),

                      // Wrap ExpansionTiles in a white background container with shadow
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: ExpansionTile(
                          title: Text(
                            "طلبات جديده",
                            style: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          children: [
                            FadeInDown(
                              duration: const Duration(milliseconds: 500),
                              child: _buildDocumentationCard(
                                "مستند الدخل الشخضي",
                                '١٧ فبراير ٢٠٢٥',
                                Iconsax.document_upload,
                                isUploadItem: true,
                              ),
                            ),
                            FadeInDown(
                              duration: const Duration(milliseconds: 600),
                              child: _buildDocumentationCard(
                                "مستند القيد العائلي",
                                '16 فبراير ٢٠٢٥',
                                Iconsax.document_upload,
                                isUploadItem: true,
                              ),
                            ),
                            FadeInDown(
                              duration: const Duration(milliseconds: 700),
                              child: _buildDocumentationCard(
                                "مستند شهادات الميلاد",
                                '15 فبراير ٢٠٢٥',
                                Iconsax.document_upload,
                                isUploadItem: true,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      Divider(),
                      const SizedBox(height: 20),

                      // Second Section: Downloadable items without pop-up dialog
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: ExpansionTile(
                          title: Text(
                            "مستندات تم رفعها سابقا",
                            style: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          children: [
                            FadeInDown(
                              duration: const Duration(milliseconds: 500),
                              child: _buildDocumentationCard(
                                "مستند عقد الايجار",
                                '١٧ فبراير ٢٠٢٥',
                                Iconsax.document_download,
                                isUploadItem: false, // This is for download items
                              ),
                            ),
                            FadeInDown(
                              duration: const Duration(milliseconds: 600),
                              child: _buildDocumentationCard(
                                "مستند كشف طبي",
                                '3 يناير ٢٠٢٥',
                                Iconsax.document_download,
                                isUploadItem: false, // This is for download items
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Menu item builder
  PopupMenuItem<String> _buildMenuItem(String text, String value, IconData icon) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Text(
            text,
            style: GoogleFonts.cairo(color: Colors.white),
          ),
        ],
      ),
    );
  }

  // Handle menu selection
  void _handleMenuSelection(String value) {
    final routes = {
      "profile": () => ProfileScreen(),
      "assessment": () => AssessmentScreen(),
      "balance": () => MonthlyBalanceScreen(),
      "request_aid": () => NeedsOrdersScreen(),
      "notification": () => NotificationsScreen(),
      "reports": () => ReportsScreen(),
      "documents": () => DocumentsScreen(),
    };

    if (routes.containsKey(value)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => routes[value]!(),
        ),
      );
    } else if (value == "signout") {
      showSignOutDialog(context); // Call the reusable dialog function
    }
  }

  // Build documentation card
  Widget _buildDocumentationCard(String title, String date, IconData icon, {required bool isUploadItem}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: isUploadItem ? _uploadItemColor : _downloadItemColor, // Dynamic color
        borderRadius: BorderRadius.circular(15),
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isUploadItem ? _uploadItemColor : _downloadItemColor, // Dynamic background color
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15), // Rounded corners
          ),
          padding: const EdgeInsets.all(10),
          shadowColor: Colors.black.withOpacity(0.1), // Optional shadow to make it stand out
        ),
        onPressed: () {
          if (isUploadItem) {
            _showDocumentUploadDialog(context, title, icon); // Upload dialog
          } else {
            _downloadDocument(title, icon); // Download directly without pop-up
          }
        },
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: Colors.green),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        title,
                        style: GoogleFonts.cairo(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black, // Custom text color
                        ),
                      ),
                      Text(
                        date,
                        style: GoogleFonts.cairo(
                          fontSize: 13,
                          color: Colors.grey[600], // Custom date color
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      )
      ,
    );
  }

  // Handle document upload
  void _showDocumentUploadDialog(BuildContext context, String title, IconData icon) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Center(child: Text("ارفاق المستندات ", style: GoogleFonts.cairo())),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDocumentItem(title, icon),
            ],
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  child: Text(
                    "الغاء",
                    style: GoogleFonts.cairo(color: Colors.red),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _showSuccessMessage(context);
                  },
                  child: Text("ارفاق المستندات", style: GoogleFonts.cairo(color: Colors.green)),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  // Show success message
  void _showSuccessMessage(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("تم ارفاق المستندات بنجاح", style: GoogleFonts.cairo()),
        duration: Duration(seconds: 2),
        backgroundColor: AppColorsData.lightGreen,
      ),
    );
  }

  // Handle document download directly
  void _downloadDocument(String title, IconData icon) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("تم تحميل المستند: $title", style: GoogleFonts.cairo()),
        duration: Duration(seconds: 2),
        backgroundColor: AppColorsData.lightGreen,
      ),
    );
  }
  Widget _buildDocumentItem(String title, IconData icon) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.end, // Aligns the row to the end
        children: [
          Expanded(
            child: Text(
              title,
              style: GoogleFonts.cairo(),
              textAlign: TextAlign.right, // Aligns text to the right
            ),
          ),
          SizedBox(width: 20),
          Icon(icon, color: Colors.green), // Icon on the right
        ],
      ),
      onTap: () {
        // Handle the document selection here if needed
      },
    );
  }

}
