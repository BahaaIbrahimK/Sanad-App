import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../Core/Utils/App Colors.dart';
import '../../../../../core/Utils/signoutMessage.dart';
import '../../../Assessment/presenation/view/assessment_view.dart';
import '../../../Documents/presentation/view/Documents.dart';
import '../../../Monthly_Balance/presenation/view/monthly_balance_view.dart';
import '../../../NeedsOrders/presenation/view/needs_orders_view.dart';
import '../../../Profile/presenation/view/Profile_view.dart';
import '../../../Reports/presentation/view/Report.dart';


class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  _NotificationsScreenState createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _animation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(color: Colors.white),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    PopupMenuButton<String>(
                      icon: Icon(Icons.menu, size: 30, color: Colors.green[700]),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      color: Colors.green[700],
                      elevation: 8,
                      itemBuilder: (BuildContext context) => [
                        _buildMenuItem("الملف الشخصي", "profile", Icons.person),
                        _buildMenuItem("تقييم الحالة", "assessment", Icons.assessment),
                        _buildMenuItem("المحفظه الماليه", "balance", Icons.account_balance_wallet),
                        _buildMenuItem("شركاء النجاح", "request_aid", Icons.help_outline),
                        _buildMenuItem("الاشعارات", "notification", Icons.notifications),
                        _buildMenuItem("الوثائق", "documents", Icons.file_copy_rounded),
                        _buildMenuItem("تقارير المساعده الشهريه", "reports", Icons.monetization_on),
                        _buildMenuItem("تسجيل الخروج", "signout", Icons.logout),
                      ],
                      onSelected: _handleMenuSelection,
                    ),
                    Image.asset(
                      "assets/images/logo.png", // Replace with your logo path
                      height: 50,
                      fit: BoxFit.contain,
                    ), // Placeholder for alignment
                  ],
                ),
              ),

              // Content Section
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: ListView(
                    children: [
                      const SizedBox(height: 24),

                      // Notification Cards
                      FadeInDown(
                        duration: const Duration(milliseconds: 500),
                        child: _buildNotificationCard(
                          "اثبات الدخل",
                          Iconsax.info_circle,
                          Colors.orange,
                            '17 فبراير ٢٠٢٥'
                        ),
                      ),
                      SizedBox(height: 20,),
                      FadeInDown(
                        duration: const Duration(milliseconds: 600),
                        child: _buildNotificationCard(
                          "عقد الايجار",
                          Iconsax.info_circle,
                          Colors.orange,
                            '16 فبراير ٢٠٢٥'
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  PopupMenuItem<String> _buildMenuItem(String text, String value, IconData icon) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Text(
            text,
            style: GoogleFonts.cairo(color: Colors.white),
          ),
        ],
      ),
    );
  }

  void _handleMenuSelection(String value) {
    final routes = {
      "profile": () => ProfileScreen(),
      "assessment": () => AssessmentScreen(),
      "balance": () => MonthlyBalanceScreen(),
      "request_aid": () => NeedsOrdersScreen(),
      "notification": () => NotificationsScreen(),
      "reports": () => ReportsScreen(),
      "documents": () => DocumentsScreen(),
    };

    if (routes.containsKey(value)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => routes[value]!(),
        ),
      );
    } else if (value == "signout") {
      showSignOutDialog(context); // Call the reusable dialog function
    }
  }

  Widget _buildNotificationCard(
      String title,
      IconData icon,
      Color color,
      String date,
      ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 1,
            offset: const Offset(0,1),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      " مطلوب تحميل $title",
                      style: GoogleFonts.cairo(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      date,
                      style: GoogleFonts.cairo(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  void _showDocumentUploadDialog(BuildContext context, title) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Center(child: Text("تحميل المستندات ", style: GoogleFonts.cairo())),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDocumentItem(title, Icons.upload),
            ],
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  child: Text(
                    "الغاء",
                    style: GoogleFonts.cairo(color: Colors.red),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                ),
                TextButton(
                  onPressed: () {
                    // Show success message
                    Navigator.of(context).pop(); // Close the dialog
                    _showSuccessMessage(context);
                  },
                  child: Text("ارفاق المستندات", style: GoogleFonts.cairo(color: Colors.green),),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  Widget _buildDocumentItem(String title, IconData icon) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.end, // Aligns the row to the end
        children: [
          Expanded(
            child: Text(
              title,
              style: GoogleFonts.cairo(),
              textAlign: TextAlign.right, // Aligns text to the right
            ),
          ),
          SizedBox(width: 20),
          Icon(icon, color: Colors.green), // Icon on the right
        ],
      ),
      onTap: () {
        // Handle the document selection here if needed
      },
    );
  }

  void _showSuccessMessage(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text("تم ارفاق المستندات بنجاح", style: GoogleFonts.cairo()),
          duration: Duration(seconds: 2),
          backgroundColor: AppColorsData.lightGreen
      ),
    );
  }

}