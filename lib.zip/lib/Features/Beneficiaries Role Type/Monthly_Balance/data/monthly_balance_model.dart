class MonthlyBalance {
  final double totalBalance;
  final double remainingBalance;
  final double paid;
  final List<OrderModel> orders;
  final int purchaseCount;
  final double monthlyAverage;

  MonthlyBalance({
    required this.totalBalance,
    required this.remainingBalance,
    required this.paid,
    required this.orders,
    required this.purchaseCount,
    required this.monthlyAverage,
  });

  factory MonthlyBalance.fromFirestore(Map<String, dynamic> data) {
    final List<dynamic> ordersData = data['orders'] ?? [];
    final List<OrderModel> ordersList = ordersData
        .map((orderData) => OrderModel.fromFirestore(orderData))
        .toList();

    return MonthlyBalance(
      totalBalance: (data['totalBalance'] ?? 0).toDouble(),
      remainingBalance: (data['remainingBalance'] ?? 0).toDouble(),
      paid: (data['paid'] ?? 0).toDouble(),
      orders: ordersList,
      purchaseCount: data['purchaseCount'] ?? 0,
      monthlyAverage: (data['monthlyAverage'] ?? 0).toDouble(),
    );
  }

  factory MonthlyBalance.empty() {
    return MonthlyBalance(
      totalBalance: 0,
      remainingBalance: 0,
      paid: 0,
      orders: [],
      purchaseCount: 0,
      monthlyAverage: 0,
    );
  }
}

// Part 2: Order Model
class OrderModel {
  final String title;
  final String date;
  final String amount;
  final String? id;

  OrderModel({
    required this.title,
    required this.date,
    required this.amount,
    this.id,
  });

  factory OrderModel.fromFirestore(Map<String, dynamic> data) {
    return OrderModel(
      id: data['id'],
      title: data['title'] ?? '',
      date: data['date'] ?? '',
      amount: data['amount'] ?? '',
    );
  }
}
