import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';

import '../../../../../core/Utils/signoutMessage.dart';
import '../../../../Moderator Role Type/Beneficiary Details/presenation/view/notifications_view.dart';
import '../../../Assessment/presenation/view/assessment_view.dart';
import '../../../Cart/presenation/view/cart_view.dart';
import '../../../Documents/presentation/view/Documents.dart';
import '../../../Grocery/presenation/view/grocery_details_view.dart';
import '../../../NeedsOrders/presenation/view/needs_orders_view.dart';
import '../../../Profile/presenation/view/Profile_view.dart';
import '../../../Reports/presentation/view/Report.dart';

class MonthlyBalanceScreen extends StatefulWidget {
  const MonthlyBalanceScreen({super.key});

  @override
  State<MonthlyBalanceScreen> createState() => _MonthlyBalanceScreenState();
}

class _MonthlyBalanceScreenState extends State<MonthlyBalanceScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _animation;

  static const double _totalBalance = 2500;
  static const double _remainingBalance = 900;
  static const double _paid = _totalBalance-_remainingBalance;

  final List<Map<String, dynamic>> orders = [
    {
      'title': 'أسواق التميمي',
      'date': '١٥ فبراير ٢٠٢٥',
      'amount': '١٥٠ ريال',
    },
    {
      'title': 'صيدلية الحياه',
      'date': '١٦ فبراير ٢٠٢٥',
      'amount': '٢٥٠ ريال',
    },
    {
      'title': 'صيدلية الرحمه',
      'date': '١٧ فبراير ٢٠٢٥',
      'amount': '٣٠٠ ريال',
    },
  ];


  List<PopupMenuItem<String>> _buildMenuItems(BuildContext context) {
    final menuItems = [
      {
        'text': 'الملف الشخصي',
        'value': 'profile',
        'icon': Icons.person_outline,
        'description': 'عرض وتعديل الملف الشخصي'
      },
      {
        'text': 'تقييم الحالة',
        'value': 'assessment',
        'icon': Icons.assessment_outlined,
        'description': 'تقييم الحالة الحالية'
      },
      {
        'text': 'الرصيد الشهري',
        'value': 'balance',
        'icon': Icons.account_balance_wallet_outlined,
        'description': 'عرض تفاصيل الرصيد'
      },
      {
        'text': 'طلب معونة',
        'value': 'request_aid',
        'icon': Icons.help_outline,
        'description': 'تقديم طلب معونة جديد'
      },
      {
        'text': 'السلة',
        'value': 'cart',
        'icon': Icons.shopping_cart_outlined,
        'description': 'عرض محتويات السلة'
      },
    ];

    return menuItems.map((item) => PopupMenuItem<String>(
      value: item['value'] as String,
      child: Container(
        constraints: const BoxConstraints(minWidth: 200),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                item['icon'] as IconData,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item['text'] as String,
                    style: GoogleFonts.cairo(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    item['description'] as String,
                    style: GoogleFonts.cairo(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    )).toList();
  }
  PopupMenuItem<String> _buildMenuItem(String text, String value, IconData icon) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Text(
            text,
            style: GoogleFonts.cairo(color: Colors.white),
          ),
        ],
      ),
    );
  }
  void _handleMenuSelection(String value) {
    final routes = {
      "profile": () => ProfileScreen(),
      "assessment": () => AssessmentScreen(),
      "balance": () => MonthlyBalanceScreen(),
      "request_aid": () => NeedsOrdersScreen(),
      "notification": () => NotificationsScreen(),
      "reports": () => ReportsScreen(),
      "documents": () => DocumentsScreen(),
    };

    if (routes.containsKey(value)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => routes[value]!(),
        ),
      );
    } else if (value == "signout") {
      showSignOutDialog(context); // Call the reusable dialog function
    }
  }

  Widget _buildOrderItem(Map<String, dynamic> order) {

    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                // Order Icon
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green[50],
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(
                    Icons.shopping_cart_rounded,
                    color: Colors.green[700],
                    size: 24,
                  ),
                ),
                const SizedBox(width: 16),

                // Order Details
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        order['title'] as String,
                        style: GoogleFonts.cairo(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text(
                            order['date'] as String,
                            style: GoogleFonts.cairo(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Amount and Status
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      order['amount'] as String,
                      style: GoogleFonts.cairo(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.green[700],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOrderDetailsSheet(Map<String, dynamic> order) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.7,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            margin: const EdgeInsets.symmetric(vertical: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Content
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // Header
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green[50],
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        order['icon'] as IconData,
                        color: Colors.green[700],
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            order['title'] as String,
                            style: GoogleFonts.cairo(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            order['date'] as String,
                            style: GoogleFonts.cairo(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Order details sections...
                // Add more details as needed

                // Action buttons
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green[700],
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: () {
                          },
                          child: Text(
                            'عرض التفاصيل',
                            style: GoogleFonts.cairo(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  @override
  void initState() {
    super.initState();
    _initializeAnimation();
  }

  void _initializeAnimation() {
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _animation = Tween<double>(
      begin: 0,
      end: _paid / _totalBalance,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _controller.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
          Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
            color: Colors.white,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              PopupMenuButton<String>(
                icon: Icon(Icons.menu, size: 30, color: Colors.green[700]),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                color: Colors.green[700],
                elevation: 8,
                itemBuilder: (BuildContext context) => [
                  _buildMenuItem("الملف الشخصي", "profile", Icons.person),
                  _buildMenuItem("تقييم الحالة", "assessment", Icons.assessment),
                  _buildMenuItem("المحفظه الماليه", "balance", Icons.account_balance_wallet),
                  _buildMenuItem("شركاء النجاح", "request_aid", Icons.help_outline),
                  _buildMenuItem("الاشعارات", "notification", Icons.notifications),
                  _buildMenuItem("الوثائق", "documents", Icons.file_copy_rounded),
                  _buildMenuItem("تقارير المساعده الشهريه", "reports", Icons.monetization_on),
                  _buildMenuItem("تسجيل الخروج", "signout", Icons.logout),
                ],
                onSelected: _handleMenuSelection,
              ),
              Image.asset(
                "assets/images/logo.png",
                height: 70,
                fit: BoxFit.contain,
              ),
            ],
          ),
                ),
              Expanded(
                child: CustomScrollView(
                  slivers: [
                    SliverToBoxAdapter(
                      child: _buildContent(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSliverAppBar() {
    return SliverAppBar(
      expandedHeight: 70, // Height of the app bar when expanded
      floating: false,
      pinned: true,
      elevation: 0,
      backgroundColor: Colors.green, // Set the background color to green
      flexibleSpace: FlexibleSpaceBar(
        title: Text(
          'الرصيد الشهري',
          style: GoogleFonts.cairo(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white, // Set the font color to white
          ),
        ),
        centerTitle: true,
        background: Container(
          color: Colors.green, // Ensure the background is green
        ),
      ),
      leading: PopupMenuButton<String>(
        icon: const Icon(Icons.menu, size:22 ,color: Colors.white), // Set menu icon color to white
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        color: Colors.green, // Set popup menu background color
        elevation: 8,
        itemBuilder: _buildMenuItems,
        onSelected: _handleMenuSelection,
      ),
    );
  }
  // [Previous imports and code remain the same]

  Widget _buildOrdersList() {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: orders.length,
      itemBuilder: (context, index) {
        return FadeInRight(
          duration: const Duration(milliseconds: 500),
          delay: Duration(milliseconds: 100 * index), // Stagger animations
          child: _buildOrderItem(orders[index]),
        );
      },
    );
  }

  Widget _buildContent() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 24),
          FadeInDown(
            duration: const Duration(milliseconds: 500),
            child: _buildBalanceCard(),
          ),
          const SizedBox(height: 24),
          FadeInLeft(
            duration: const Duration(milliseconds: 500),
            child: _buildStatisticsRow(),
          ),
          const SizedBox(height: 32),
          FadeInRight(
            duration: const Duration(milliseconds: 500),
            child: _buildSectionTitle('طلباتك السابقة'),
          ),
          const SizedBox(height: 16),
          _buildOrdersList(), // Use the new method here
          const SizedBox(height: 24),
        ],
      ),
    );
  }


  Widget _buildBalanceCard() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.green[700]!,
            Colors.green[500]!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.green.withOpacity(0.2),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'الرصيد المتبقي',
                      style: GoogleFonts.cairo(
                        color: Colors.white70,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$_remainingBalance رس',
                      style: GoogleFonts.cairo(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(left:20.0),
                  child: Container(
                    width: 70,
                    height: 70,
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Image.asset(
                      "assets/images/qr-code.jpg",
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildProgressLabel(),
                const SizedBox(height: 8),
                _buildProgressBar(),
                const SizedBox(height: 16),
                _buildBalanceDetails(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressLabel() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'نسبة الاستهلاك',
          style: GoogleFonts.cairo(
            color: Colors.white70,
            fontSize: 14,
          ),
        ),
        Text(
          '${((_paid / _totalBalance) * 100).toStringAsFixed(1)}%',
          style: GoogleFonts.cairo(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildProgressBar() {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Stack(
            children: [
              Container(
                height: 12,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 12,
                width: MediaQuery
                    .of(context)
                    .size
                    .width  * _animation.value,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBalanceDetails() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _buildBalanceDetailItem('كافة ماتم ايداعه', '$_totalBalance رس'),
        Container(
          width: 1,
          height: 40,
          color: Colors.white24,
        ),
        _buildBalanceDetailItem('الاستهلاك', '$_paid رس'),
      ],
    );
  }

  Widget _buildBalanceDetailItem(String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(
            label,
            style: GoogleFonts.cairo(
              color: Colors.white70,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatisticsRow() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            'عدد عمليات الشراء',
            '12',
            Icons.shopping_bag_outlined,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildStatCard(
            'المتوسط الشهري',
            '450 رس',
            Icons.timeline,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.green[50],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: Colors.green[700], size: 24),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: GoogleFonts.cairo(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: GoogleFonts.cairo(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.green[800],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(
        title,
        style: GoogleFonts.cairo(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.green[800],
        ),
      ),
    );
  }
}