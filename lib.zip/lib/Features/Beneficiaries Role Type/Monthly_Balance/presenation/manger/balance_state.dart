part of 'balance_cubit.dart';

@immutable
abstract class BalanceState {}

class BalanceInitial extends BalanceState {}

class MonthlyBalanceInitial extends BalanceState {}

class MonthlyBalanceLoading extends BalanceState {}

class MonthlyBalanceLoaded extends BalanceState {
  final MonthlyBalance balance;

   MonthlyBalanceLoaded(this.balance);

  List<Object> get props => [balance];
}

class MonthlyBalanceError extends BalanceState {
  final String message;

   MonthlyBalanceError(this.message);

  List<Object> get props => [message];
}
