import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:meta/meta.dart';

import '../../data/monthly_balance_model.dart';

part 'balance_state.dart';

class BalanceCubit extends Cubit<BalanceState> {
  BalanceCubit() : super(BalanceInitial());

  MonthlyBalance? balance;
  List<OrderModel>? orders;

  // Fetch current user's monthly balance data
  Future<void> fetchMonthlyBalance(userId) async {
    try {
      emit(MonthlyBalanceLoading());

      final DateTime now = DateTime.now();
      final String monthYear = '${now.month}-${now.year}';
      print(monthYear);
      final DocumentSnapshot balanceDoc =
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('monthly_balances')
          .doc(monthYear)
          .get();

      if (!balanceDoc.exists) {
        emit(MonthlyBalanceError('No balance data found for this month'));
        return;
      }

      final Map<String, dynamic> data =
      balanceDoc.data() as Map<String, dynamic>;
      balance = MonthlyBalance.fromFirestore(data);

      emit(MonthlyBalanceLoaded(balance!));
    } catch (e) {
      emit(
        MonthlyBalanceError('Failed to load monthly balance: ${e.toString()}'),
      );
    }
  }

  // Fetch order history for the current user
  Future<void> fetchOrderHistory(userId) async {
    try {
      emit(MonthlyBalanceLoading());

      final QuerySnapshot ordersSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('orders')
          .orderBy('timestamp', descending: true)
          .limit(10)
          .get();

      orders = ordersSnapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return OrderModel.fromFirestore({...data, 'id': doc.id});
      }).toList();

      // Get the current balance data
      final DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .get();

      if (!userDoc.exists) {
        emit(MonthlyBalanceError('User data not found'));
        return;
      }

      final Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;

      final MonthlyBalance balance = MonthlyBalance(
        totalBalance: (userData['totalBalance'] ?? 0).toDouble(),
        remainingBalance: (userData['remainingBalance'] ?? 0).toDouble(),
        paid: (userData['totalBalance'] ?? 0) - (userData['remainingBalance'] ?? 0),
        orders: orders!,
        purchaseCount: userData['purchaseCount'] ?? 0,
        monthlyAverage: (userData['monthlyAverage'] ?? 0).toDouble(),
      );

      emit(MonthlyBalanceLoaded(balance));
    } catch (e) {
      emit(MonthlyBalanceError('Failed to load order history: ${e.toString()}'));
    }
  }

  // Method to update monthly balance data (for admin or system use)
  Future<void> updateMonthlyBalance({
    required double totalBalance,
    required double remainingBalance,
    required String userId
  }) async {
    try {
      emit(MonthlyBalanceLoading());

      // Get the current month and year
      final DateTime now = DateTime.now();
      final String monthYear = '${now.month}-${now.year}';

      // Calculate the paid amount
      final double paid = totalBalance - remainingBalance;

      // Update the monthly balance document
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('monthly_balances')
          .doc(monthYear)
          .set({
        'totalBalance': totalBalance,
        'remainingBalance': remainingBalance,
        'paid': paid,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      // Also update the user document with the latest balance
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .update({
        'totalBalance': totalBalance,
        'remainingBalance': remainingBalance,
      });

      // Fetch the updated data
      await fetchMonthlyBalance(userId);
    } catch (e) {
      emit(MonthlyBalanceError('Failed to update monthly balance: ${e.toString()}'));
    }
  }
}