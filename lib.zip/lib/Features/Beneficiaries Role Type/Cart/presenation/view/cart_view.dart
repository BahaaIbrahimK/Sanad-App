import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';
import 'package:iconsax/iconsax.dart'; // Import iconsax
import 'package:flutter_slidable/flutter_slidable.dart'; // Import flutter_slidable

import '../../../Assessment/presenation/view/assessment_view.dart';
import '../../../Monthly_Balance/presenation/view/monthly_balance_view.dart';
import '../../../NeedsOrders/presenation/view/needs_orders_view.dart';
import '../../../Profile/presenation/view/Profile_view.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _controller.forward();
  }

  List<Map<String, dynamic>> cartItems = [
    {
      "name": "بنادول إكسترا",
      "price": 25,
      "quantity": 2,
      "image": "assets/images/panadol.jpg",
    },
    {
      "name": "بنادول إكسترا",
      "price": 25,
      "quantity": 2,
      "image": "assets/images/panadol.jpg",
    }, {
      "name": "بنادول إكسترا",
      "price": 25,
      "quantity": 2,
      "image": "assets/images/panadol.jpg",
    }, {
      "name": "بنادول إكسترا",
      "price": 25,
      "quantity": 2,
      "image": "assets/images/panadol.jpg",
    }, {
      "name": "بنادول إكسترا",
      "price": 25,
      "quantity": 2,
      "image": "assets/images/panadol.jpg",
    },
  ];

  double get totalPrice {
    return cartItems.fold(
      0,
          (sum, item) => sum + (item["price"] * item["quantity"]),
    );
  }

  void _handleMenuSelection(String value) {
    final routes = {
      "profile": () => ProfileScreen(),
      "assessment": () => AssessmentScreen(),
      "balance": () => MonthlyBalanceScreen(),
      "request_aid": () => NeedsOrdersScreen(),
    };

    if (routes.containsKey(value)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => routes[value]!(),
        ),
      );
    }
  }

  void _removeItem(int index) {
    setState(() {
      cartItems.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(context),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 24),
                      FadeInDown(
                        duration: const Duration(milliseconds: 500),
                        child: Text(
                          "السلة",
                          style: GoogleFonts.cairo(
                            fontSize: 28, // Increased font size
                            fontWeight: FontWeight.bold,
                            color: Colors.green[800],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Expanded(
                        child: _buildCartItemsList(),
                      ),
                      const SizedBox(height: 16),
                      FadeInUp(
                        duration: const Duration(milliseconds: 500),
                        child: _buildTotalPriceRow(),
                      ),
                      const SizedBox(height: 16),
                      FadeInUp(
                        duration: const Duration(milliseconds: 500),
                        child: _buildCheckoutButton(),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [ // Added subtle shadow
          BoxShadow(
            color: Colors.black12,
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          PopupMenuButton<String>(
            icon: Icon(Icons.menu, size: 30, color: Colors.green[700]), // Using iconsax menu
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            color: Colors.green[700],
            elevation: 8,
            itemBuilder: (BuildContext context) => [
              _buildMenuItem("الملف الشخصي", "profile", Iconsax.user), // Using iconsax user
              _buildMenuItem("تقييم الحالة", "assessment", Iconsax.health), // Using iconsax health
              _buildMenuItem("الرصيد الشهري", "balance", Iconsax.wallet_3), // Using iconsax wallet
              _buildMenuItem("طلب معونة", "request_aid", Iconsax.message_question), // Using iconsax question
              _buildMenuItem("السلة", "cart", Iconsax.bag_2), // Using iconsax bag
            ],
            onSelected: _handleMenuSelection,
          ),
          Image.asset(
            "assets/images/logo.png",
            height: 70,
            fit: BoxFit.contain,
          ),
        ],
      ),
    );
  }

  Widget _buildCartItemsList() {
    return ListView.builder(
      itemCount: cartItems.length,
      itemBuilder: (context, index) {
        final item = cartItems[index];
        return FadeInLeft(
          duration: Duration(milliseconds: 300 + (index * 50)),
          child: Slidable( // Wrap with Slidable
            key: Key(item["name"]),
            endActionPane: ActionPane(
              motion: const ScrollMotion(),
              children: [
                SlidableAction(
                  onPressed: (context) => _removeItem(index),
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                  icon: Iconsax.trash, // Using iconsax trash
                  label: 'حذف',
                  borderRadius: BorderRadius.circular(12),
                ),
              ],
            ),
            child: _buildCartItemCard(item, index), // Pass index to the card
          ),
        );
      },
    );
  }

  Widget _buildCartItemCard(Map<String, dynamic> item, int index) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [ // Added subtle shadow
          BoxShadow(
            color: Colors.black12,
            blurRadius: 3,
            offset: Offset(0, 1),
          ),
        ],
      ),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                item["image"],
                height: 80, // Increased image size
                width: 80, // Increased image size
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item["name"],
                    style: GoogleFonts.cairo(
                      fontSize: 20, // Increased font size
                      fontWeight: FontWeight.bold,
                      color: Colors.green[900], // Darker green
                    ),
                  ),
                  Text(
                    "السعر: ${item["price"]} رس",
                    style: GoogleFonts.cairo(
                      fontSize: 16,
                      color: Colors.grey[700],
                    ),
                  ),
                ],
              ),
            ),
            _buildQuantityControls(item),
          ],
        ),
      ),
    );
  }

  Widget _buildQuantityControls(Map<String, dynamic> item) {
    return Row(
      children: [
        IconButton(
          onPressed: () {
            setState(() {
              if (item["quantity"] > 1) { // Prevent quantity from going to 0
                item["quantity"]--;
              }
            });
          },
          icon: Icon(
            Iconsax.minus_square, // Using iconsax minus
            color: Colors.red,
          ),
        ),
        Text(
          "${item["quantity"]}",
          style: GoogleFonts.cairo(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        IconButton(
          onPressed: () {
            setState(() {
              item["quantity"]++;
            });
          },
          icon: Icon(
            Iconsax.add_square, // Using iconsax add
            color: Colors.green,
          ),
        ),
      ],
    );
  }

  Widget _buildTotalPriceRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          "المبلغ الإجمالي:",
          style: GoogleFonts.cairo(
            fontSize: 20, // Increased font size
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          "$totalPrice رس",
          style: GoogleFonts.cairo(
            fontSize: 20, // Increased font size
            color: Colors.green[700],
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildCheckoutButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          // Complete order logic
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green[700],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(
            vertical: 14,
          ),
          elevation: 5, // Added elevation
        ),
        child: Text(
          "إتمام الطلب",
          style: GoogleFonts.cairo(
            fontSize: 18, // Increased font size
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  PopupMenuItem<String> _buildMenuItem(String text, String value, IconData icon) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 22), // Increased icon size
          const SizedBox(width: 8),
          Text(
            text,
            style: GoogleFonts.cairo(color: Colors.white),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}