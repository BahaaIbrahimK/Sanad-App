import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

// Assuming you have these imports in your project
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/presenation/view/changePassoword.dart';
import 'package:sanad/core/Utils/signoutMessage.dart';

import '../../../../Moderator Role Type/Beneficiary Details/presenation/manger/profile/profile_cubit.dart';
import '../../../../Moderator Role Type/Beneficiary Details/presenation/manger/profile/profile_state.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Profile data map
  Map<String, String> profileData = {
    'الاسم': 'أحمد محمد',
    'البريد الإلكتروني': 'ahmed@example.com',
    'رقم الهاتف': '٠٥٠٠٠٠٠٠٠٠',
    'المنطقة': 'الرياض',
    'نوع المستخدم': 'باحث اجتماعي',
    'تاريخ الانضمام': '٢٠٢٤/٠١/٠١',
  };

  // Editing controllers
  late Map<String, TextEditingController> _controllers;
  bool _isEditMode = false;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    // Initialize controllers for editable fields
    _controllers = {
      'البريد الإلكتروني': TextEditingController(text: profileData['البريد الإلكتروني']),
      'رقم الهاتف': TextEditingController(text: profileData['رقم الهاتف']),
      'المنطقة': TextEditingController(text: profileData['المنطقة']),
    };
  }

  @override
  void dispose() {
    // Dispose controllers
    _controllers.forEach((key, controller) => controller.dispose());
    super.dispose();
  }

  void _toggleEditMode() {
    setState(() {
      if (_isEditMode) {
        // Validate and save changes
        if (_formKey.currentState!.validate()) {
          // Update profile data
          _controllers.forEach((key, controller) {
            profileData[key] = controller.text;
          });
        } else {
          return; // Don't exit edit mode if validation fails
        }
      }
      _isEditMode = !_isEditMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ProfileCubit()..fetchUserData(""),
      child: BlocConsumer<ProfileCubit, ProfileState>(
        listener: (context, state) {},
        builder: (context, state) {
          return Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              backgroundColor: Colors.grey[50],
              body: SafeArea(
                child: Column(
                  children: [
                    _buildAppBar(),
                    Expanded(
                        child: _isEditMode
                            ? _buildEditProfileContent()
                            : _buildProfileContent()
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildMenu(),
          Image.asset(
            "assets/images/logo.png",
            height: 70,
            fit: BoxFit.contain,
          ),
        ],
      ),
    );
  }

  Widget _buildMenu() {
    return PopupMenuButton<String>(
      icon: Icon(Icons.menu, size: 28, color: Colors.green[700]),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: Colors.green[700],
      elevation: 8,
      offset: const Offset(0, 40),
      itemBuilder: (BuildContext context) => [
        _buildMenuItem("الملف الشخصي", "profile", Icons.person),
        _buildMenuItem(
          "تقييم الطلبات الجديدة",
          "evaluate_accounts",
          Icons.account_balance_wallet,
        ),
        _buildMenuItem(
          "طلبات المستفيدين المقبولة",
          "organize_shipments",
          Icons.receipt_long,
        ),
        _buildMenuItem("إدارة المتاجر", "market", Icons.shopping_cart),
        _buildMenuItem("تسجيل الخروج", "logout", Icons.logout),
      ],
      onSelected: (value) => _handleMenuSelection(context, value),
    );
  }

  void _handleMenuSelection(BuildContext context, String value) {
    // Implement navigation logic for menu items
    // This is a placeholder implementation
    switch (value) {
      case "logout":
        showSignOutDialog(context);
        break;
      default:
      // Handle other menu items
        print('Selected: $value');
    }
  }

  PopupMenuItem<String> _buildMenuItem(
      String text,
      String value,
      IconData icon,
      ) {
    return PopupMenuItem<String>(
      value: value,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              text,
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(width: 12),
            Icon(icon, color: Colors.white, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildEditProfileContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            _buildProfileHeader(),
            const SizedBox(height: 24),
            _buildEditableProfileInformation(),
            const SizedBox(height: 24),
            _buildSaveButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildProfileHeader(),
          const SizedBox(height: 24),
          _buildProfileInformation(),
          const SizedBox(height: 24),
          _buildActionButtons(),
        ],
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Column(
      children: [
        Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.green[50],
            border: Border.all(color: Colors.green[700]!, width: 3),
          ),
          child: Center(
            child: Text(
              'أم',
              style: GoogleFonts.cairo(
                fontSize: 40,
                fontWeight: FontWeight.bold,
                color: Colors.green[700],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          profileData['الاسم']!,
          style: GoogleFonts.cairo(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        Text(
          profileData['نوع المستخدم']!,
          style: GoogleFonts.cairo(fontSize: 16, color: Colors.grey[600]),
        ),
      ],
    );
  }

  Widget _buildProfileInformation() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: profileData.entries.map((entry) {
          if (entry.key == 'الاسم' || entry.key == 'نوع المستخدم')
            return const SizedBox.shrink();
          return _buildInfoItem(entry.key, entry.value);
        }).toList(),
      ),
    );
  }

  Widget _buildEditableProfileInformation() {
    final editableFields = [
      {'key': 'البريد الإلكتروني', 'icon': Icons.email},
      {'key': 'رقم الهاتف', 'icon': Icons.phone},
      {'key': 'المنطقة', 'icon': Icons.location_on},
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: editableFields.map((field) {
          return _buildEditableField(
              label: field['key'] as String,
              icon: field['icon'] as IconData
          );
        }).toList(),
      ),
    );
  }

  Widget _buildInfoItem(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.grey[200]!, width: 1)),
      ),
      child: Row(
        children: [
          Icon(_getIconForLabel(label), color: Colors.green[700], size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
                Text(
                  value,
                  style: GoogleFonts.cairo(fontSize: 16, color: Colors.black87),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEditableField({
    required String label,
    required IconData icon
  }) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.grey[200]!, width: 1)),
      ),
      child: TextFormField(
        controller: _controllers[label],
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.green[700], size: 24),
          labelText: label,
          labelStyle: GoogleFonts.cairo(
            fontSize: 14,
            color: Colors.grey[600],
          ),
          border: InputBorder.none,
        ),
        style: GoogleFonts.cairo(fontSize: 16, color: Colors.black87),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'يرجى إدخال $label';
          }
          return null;
        },
      ),
    );
  }

  IconData _getIconForLabel(String label) {
    switch (label) {
      case 'البريد الإلكتروني':
        return Icons.email;
      case 'رقم الهاتف':
        return Icons.phone;
      case 'المنطقة':
        return Icons.location_on;
      case 'تاريخ الانضمام':
        return Icons.calendar_today;
      default:
        return Icons.info;
    }
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        _buildButton('تعديل الملف الشخصي', Icons.edit, _toggleEditMode),
        const SizedBox(height: 12),
        _buildButton('تغيير كلمة المرور', Icons.lock, () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ChangePasswordScreen()),
          );
        }, isOutlined: true),
      ],
    );
  }

  Widget _buildSaveButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _toggleEditMode,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green[700],
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text(
          'حفظ التعديلات',
          style: GoogleFonts.cairo(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildButton(
      String text,
      IconData icon,
      VoidCallback onPressed,
      {bool isOutlined = false}
      ) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: isOutlined ? Colors.white : Colors.green[700],
          foregroundColor: isOutlined ? Colors.green[700] : Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: isOutlined
                ? BorderSide(color: Colors.green[700]!)
                : BorderSide.none,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon),
            const SizedBox(width: 8),
            Text(
              text,
              style: GoogleFonts.cairo(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}