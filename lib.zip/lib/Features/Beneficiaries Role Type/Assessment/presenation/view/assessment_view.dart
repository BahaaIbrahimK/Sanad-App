import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';
import 'package:iconsax/iconsax.dart';


import '../../../../../core/Utils/signoutMessage.dart';
import '../../../../Moderator Role Type/Beneficiary Details/presenation/view/notifications_view.dart';
import '../../../Cart/presenation/view/cart_view.dart';
import '../../../Documents/presentation/view/Documents.dart';
import '../../../Monthly_Balance/presenation/view/monthly_balance_view.dart';
import '../../../NeedsOrders/presenation/view/needs_orders_view.dart';
import '../../../Profile/presenation/view/Profile_view.dart';
import '../../../Reports/presentation/view/Report.dart';

class AssessmentScreen extends StatefulWidget {
  const AssessmentScreen({super.key});

  @override
  _AssessmentScreenState createState() => _AssessmentScreenState();
}

class _AssessmentScreenState extends State<AssessmentScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _animation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section
              Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    PopupMenuButton<String>(
                      icon: Icon(Icons.menu, size: 30, color: Colors.green[700]),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      color: Colors.green[700],
                      elevation: 8,
                      itemBuilder: (BuildContext context) => [
                        _buildMenuItem("الملف الشخصي", "profile", Icons.person),
                        _buildMenuItem("تقييم الحالة", "assessment", Icons.assessment),
                        _buildMenuItem("المحفظه الماليه", "balance", Icons.account_balance_wallet),
                        _buildMenuItem("شركاء النجاح", "request_aid", Icons.help_outline),
                        _buildMenuItem("الاشعارات", "notification", Icons.notifications),
                        _buildMenuItem("الوثائق", "documents", Icons.file_copy_rounded),
                        _buildMenuItem("تقارير المساعده الشهريه", "reports", Icons.monetization_on),
                        _buildMenuItem("تسجيل الخروج", "signout", Icons.logout),
                      ],
                      onSelected: _handleMenuSelection,
                    ),
                    Image.asset(
                      "assets/images/logo.png",
                      height: 70,
                      fit: BoxFit.contain,
                    ),
                  ],
                ),
              ),

              // Content Section
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: ListView(
                    children: [
                      const SizedBox(height: 24),

                      // Main Content Card
                      FadeInDown(
                        duration: const Duration(milliseconds: 500),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 10,
                                offset: const Offset(0, 5),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Center(
                                child: Text(
                                  'مقبول',
                                  style: GoogleFonts.cairo(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.green[800],
                                  ),
                                ),
                              ),
                              SizedBox(height: 20,),

                              Text(
                                'تقييم الحالة',
                                style: GoogleFonts.cairo(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green[800],
                                ),
                              ),
                              const SizedBox(height: 20),
                              _buildField(
                                label: 'الدخل الشهري المقدر:',
                                hint: '2500 ريال سعودي',
                                icon: Icons.money,
                              ),
                              _buildField(
                                label: 'حالة المستفيد:',
                                hint: 'متوسط',
                                icon: Icons.person,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  PopupMenuItem<String> _buildMenuItem(String text, String value, IconData icon) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Text(
            text,
            style: GoogleFonts.cairo(color: Colors.white),
          ),
        ],
      ),
    );
  }

  void _handleMenuSelection(String value) {
    final routes = {
      "profile": () => ProfileScreen(),
      "assessment": () => AssessmentScreen(),
      "balance": () => MonthlyBalanceScreen(),
      "request_aid": () => NeedsOrdersScreen(),
      "notification": () => NotificationsScreen(),
      "reports": () => ReportsScreen(),
      "documents": () => DocumentsScreen(),
    };

    if (routes.containsKey(value)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => routes[value]!(),
        ),
      );
    } else if (value == "signout") {
      showSignOutDialog(context); // Call the reusable dialog function
    }
  }

  Widget _buildField({
    required String label,
    required String hint,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.cairo(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.green[800], // Optional: Change color to match your theme
          ),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey[300]!), // Optional: Add a border
          ),
          child: Row(
            children: [
              Icon(icon, color: Colors.grey),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  hint, // Display the hint as the content
                  style: GoogleFonts.cairo(color: Colors.grey),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildUploadButton() {
    return GestureDetector(
      onTap: () {
        // TODO: Implement upload functionality
      },
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black),
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            const Icon(Icons.camera_alt, color: Colors.black),
            const SizedBox(width: 8),
            Text('أرفق المستندات المطلوبة :', style: GoogleFonts.cairo(color: Colors.black, fontSize: 16)),
          ],
        ),
      ),
    );
  }

  Widget _buildSubmitButton() {
    return Center(
      child: ElevatedButton(
        onPressed: () {
          // TODO: Implement submit functionality
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green,
          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Text('إرسال التقييم', style: GoogleFonts.cairo(fontSize: 16, color: Colors.white)),
      ),
    );
  }
}