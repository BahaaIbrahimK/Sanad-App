import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../Assessment/presenation/view/assessment_view.dart';
import '../../../Cart/presenation/view/cart_view.dart';
import '../../../Monthly_Balance/presenation/view/monthly_balance_view.dart';
import '../../../NeedsOrders/presenation/view/needs_orders_view.dart';
import '../../../Profile/presenation/view/Profile_view.dart';

class PharmacyProductsScreen extends StatelessWidget {
  final List<Map<String, String>> products = [
    {
      "name": "Panadol Extra",
      "price": "25 ريال",
      "image": "assets/images/panadol.jpg",
    },
    {"name": "Brufen 400mg", "price": "20 ريال", "image": "assets/images/panadol.jpg"},
    {"name": "Voltaren Gel", "price": "30 ريال", "image": "assets/images/panadol.jpg"},
    {
      "name": "Prospan Syrup",
      "price": "18 ريال",
      "image": "assets/images/panadol.jpg",
    },
    {"name": "Cough Drops", "price": "15 ريال", "image": "assets/images/panadol.jpg"},
  ];

  PharmacyProductsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Menu Icon with Dropdown
                    PopupMenuButton<String>(
                      icon: Icon(Icons.menu, size: 30, color: Colors.black),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      color: Colors.blue,
                      itemBuilder:
                          (BuildContext context) => [
                            PopupMenuItem(
                              value: "profile",
                              child: Text(
                                "الملف الشخصي",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            PopupMenuItem(
                              value: "medications",
                              child: Text(
                                "الأدوية المتوفرة",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            PopupMenuItem(
                              value: "orders",
                              child: Text(
                                "طلباتي",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            PopupMenuItem(
                              value: "consult",
                              child: Text(
                                "استشارة طبية",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ],
                      onSelected: (String value) {
                        // Implement navigation logic if needed
                        switch (value) {
                          case "profile":
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ProfileScreen(),
                              ),
                            );
                            break;
                          case "assessment":
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => AssessmentScreen(),
                              ),
                            );
                            break;
                          case "balance":
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => MonthlyBalanceScreen(),
                              ),
                            );
                            break;
                          case "request_aid":
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => NeedsOrdersScreen(),
                              ),
                            );
                            break;
                          case "cart":
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => CartScreen(),
                              ),
                            );
                            break;
                        }
                      },
                    ),
                    // Logo Placeholder
                    Image.asset(
                      "assets/images/logo.png",
                      height: 80,
                      width: 80,
                      fit: BoxFit.contain,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 10),
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 0.8,
                  ),
                  itemCount: products.length,
                  itemBuilder: (context, index) {
                    final product = products[index];
                    int quantity = 0;

                    return StatefulBuilder(
                      builder: (context, setState) {
                        return Card(
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Image.asset(
                                  product["image"]!,
                                  height: 100,
                                  width: 100,
                                  fit: BoxFit.contain,
                                ),
                                Text(
                                  product["name"]!,
                                  style: GoogleFonts.cairo(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                Text(
                                  product["price"]!,
                                  style: GoogleFonts.cairo(
                                    fontSize: 14,
                                    color: Colors.grey[700],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    IconButton(
                                      onPressed:
                                          quantity > 0
                                              ? () {
                                                setState(() {
                                                  quantity--;
                                                });
                                              }
                                              : null,
                                      icon: const Icon(Icons.remove),
                                      color: Colors.red,
                                    ),
                                    Text(
                                      quantity.toString(),
                                      style: GoogleFonts.cairo(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    IconButton(
                                      onPressed: () {
                                        setState(() {
                                          quantity++;
                                        });
                                      },
                                      icon: const Icon(Icons.add),
                                      color: Colors.green,
                                    ),
                                  ],
                                ),
                                ElevatedButton.icon(
                                  onPressed: () {
                                    // Add to cart logic
                                  },
                                  icon: const Icon(
                                    Icons.shopping_cart,
                                    color: Colors.white,
                                  ),
                                  label: Text(
                                    "إضافة إلى السلة",
                                    style: GoogleFonts.cairo(
                                      fontSize: 14,
                                      color: Colors.white,
                                    ),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
