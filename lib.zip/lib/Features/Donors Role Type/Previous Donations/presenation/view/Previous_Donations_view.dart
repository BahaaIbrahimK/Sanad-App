import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart' as intl;
import 'package:sanad/Features/Donors%20Role%20Type/Donation/presenation/view/donation_view.dart';
import 'package:sanad/Features/Donors%20Role%20Type/Profile/presenation/view/Profile_view.dart';
import 'package:sanad/core/Utils/signoutMessage.dart';

class PreviousDonationsScreen extends StatefulWidget {
  const PreviousDonationsScreen({super.key});

  @override
  State<PreviousDonationsScreen> createState() => _PreviousDonationsScreenState();
}

class _PreviousDonationsScreenState extends State<PreviousDonationsScreen> {
  bool showBeneficiaries = false;

  // Sample data for available beneficiary cases
  final List<Map<String, dynamic>> beneficiaryCases = [
    {
      'id': 'CASE-001',
      'name': 'عائلة أحمد',
      'category': 'مأوى',
      'urgency': 'عاجل',
      'needed': 5000,
      'raised': 2000,
      'description': 'عائلة مكونة من 5 أفراد تحتاج إلى مساعدة في إيجار المنزل',
      'deadline': DateTime(2024, 3, 30),
      'icon': Iconsax.home,
      'documents': ['تقرير الحالة', 'وثائق رسمية'],
    },
    {
      'id': 'CASE-002',
      'name': 'طالب متفوق',
      'category': 'تعليم',
      'urgency': 'متوسط',
      'needed': 3000,
      'raised': 1500,
      'description': 'طالب متفوق يحتاج إلى دعم لإكمال دراسته الجامعية',
      'deadline': DateTime(2024, 4, 15),
      'icon': Iconsax.book,
      'documents': ['شهادات دراسية', 'توصيات'],
    },
  ];

  // Previous donations data
  final List<Map<String, dynamic>> donations = [
    {
      'id': '#12345',
      'amount': 500,
      'date': DateTime(2024, 2, 1),
      'status': 'مكتمل',
      'beneficiary': 'مؤسسة التعليم للجميع',
      'impact': 'دعم 5 طلاب',
      'isRecurring': true,
      'icon': Iconsax.book_1,
      'receipt': 'PDF-12345',
    },
    {
      'id': '#12346',
      'amount': 1000,
      'date': DateTime(2024, 1, 15),
      'status': 'مكتمل',
      'beneficiary': 'مستشفى الأمل',
      'impact': 'توفير أدوية لـ 10 مرضى',
      'isRecurring': false,
      'icon': Iconsax.health,
      'receipt': 'PDF-12346',
    },
    {
      'id': '#12347',
      'amount': 750,
      'date': DateTime(2024, 1, 30),
      'status': 'مكتمل',
      'beneficiary': 'بنك الطعام',
      'impact': 'إطعام 15 عائلة',
      'isRecurring': true,
      'icon': Iconsax.shopping_cart,
      'receipt': 'PDF-12347',
    },
    {
      'id': '#12348',
      'amount': 2000,
      'date': DateTime(2024, 2, 5),
      'status': 'مكتمل',
      'beneficiary': 'جمعية الإسكان الخيري',
      'impact': 'ترميم منزلين',
      'isRecurring': false,
      'icon': Iconsax.home,
      'receipt': 'PDF-12348',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        body: SafeArea(
          child: Column(
            children: [
          Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
            color: Colors.white,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              PopupMenuButton<String>(
                icon: Icon(Icons.menu, size: 30, color: Colors.green[700]),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                color: Colors.green[700],
                elevation: 8,
                itemBuilder: (BuildContext context) => [
                  _buildMenuItem("الملف الشخصي", "profile", Icons.person),
                  _buildMenuItem("حالة حساب المتبرع", "donor_status", Icons.account_balance_wallet),
                  _buildMenuItem("تقارير التبرعات", "donation_reports", Icons.receipt_long),
                  _buildMenuItem("تسجيل الخروج", "logout", Icons.logout), // New item added here
                ],
                onSelected: _handleMenuSelection,
              ),
              Image.asset(
                "assets/images/logo.png",
                height: 70,
                fit: BoxFit.contain,
              ),
            ],
          ),
        ),
              _buildToggleButtons(),
              Expanded(
                child: showBeneficiaries
                    ? _buildBeneficiariesList()
                    : Column(
                  children: [
                    _buildDonationStats(),

                  const SizedBox(height: 6),
                  Padding(
                    padding: const EdgeInsets.only(right:16),
                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        FadeInUp(
                          child: Text(
                            "التبرعات السابقه: ",
                            style: GoogleFonts.cairo(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                    const SizedBox(height: 6),

                    Expanded(
                      child: _buildDonationsList(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildToggleButtons() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton(
              onPressed: () => setState(() => showBeneficiaries = false),
              style: ElevatedButton.styleFrom(
                backgroundColor: !showBeneficiaries ? Colors.green[700] : Colors.grey[200],
                foregroundColor: !showBeneficiaries ? Colors.white : Colors.grey[700],
                elevation: !showBeneficiaries ? 2 : 0,
              ),
              child: Text('سجل التبرعات', style: GoogleFonts.cairo()),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton(
              onPressed: () => setState(() => showBeneficiaries = true),
              style: ElevatedButton.styleFrom(
                backgroundColor: showBeneficiaries ? Colors.green[700] : Colors.grey[200],
                foregroundColor: showBeneficiaries ? Colors.white : Colors.grey[700],
                elevation: showBeneficiaries ? 2 : 0,
              ),
              child: Text('الحالات المتاحة', style: GoogleFonts.cairo()),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBeneficiariesList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: beneficiaryCases.length,
      itemBuilder: (context, index) {
        final beneficiary = beneficiaryCases[index];
        return _buildBeneficiaryCard(beneficiary);
      },
    );
  }

  Widget _buildBeneficiaryCard(Map<String, dynamic> beneficiary) {

    return FadeInUp(
        duration: Duration(milliseconds: 500 + (beneficiaryCases.indexOf(beneficiary) * 100)),
        child: Container(
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: ExpansionTile(
                tilePadding: const EdgeInsets.all(16),
                leading: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green[50],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(beneficiary['icon'], color: Colors.green[700]),
                ),
                title: Row(
                  children: [
                    Text(
                      beneficiary['name'],
                      style: GoogleFonts.cairo(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: beneficiary['urgency'] == 'عاجل'
                            ? Colors.red[50]
                            : Colors.orange[50],
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        beneficiary['urgency'],
                        style: GoogleFonts.cairo(
                          fontSize: 12,
                          color: beneficiary['urgency'] == 'عاجل'
                              ? Colors.red[700]
                              : Colors.orange[700],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 8),
                    Text(
                      beneficiary['description'],
                      style: GoogleFonts.cairo(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    ),
                  ],
                ),
                children: [
            Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey[50],
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(15),
                bottomRight: Radius.circular(15),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Text(
              'المستندات الداعمه:',
              style: GoogleFonts.cairo(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            ...beneficiary['documents'].map<Widget>((doc) =>
        Padding(
        padding: const EdgeInsets.only(bottom: 4),
    child: Row(
    children: [
    Icon(Iconsax.document_text, size: 16, color: Colors.grey[600]),
    const SizedBox(width: 8),
    Text(
      doc,
      style: GoogleFonts.cairo(
        fontSize: 14,
        color: Colors.grey[600],
      ),
    ),
    ],
    ),
        ),
            ).toList(),
                const SizedBox(height: 16),
              ],
            ),
            ),
                ],
            ),
        ),
    );
  }

  Widget _buildHeader() {
    return FadeInDown(
      duration: const Duration(milliseconds: 500),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Iconsax.arrow_right_3),
                ),
                Text(
                  "سجل التبرعات",
                  style: GoogleFonts.cairo(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Iconsax.setting_2),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  PopupMenuItem<String> _buildMenuItem(String text, String value, IconData icon) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Text(
            text,
            style: GoogleFonts.cairo(color: Colors.white),
          ),
        ],
      ),
    );
  }

  void _handleMenuSelection(String value) {
    final routes = {
      "profile": () => ProfileDonorsScreen(),
      "donor_status": () => DonationScreen(),
      "donation_reports": () => PreviousDonationsScreen()};

    if (routes.containsKey(value)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => routes[value]!(),
        ),
      );
    } else if (value == "logout") {
      showSignOutDialog(context); // Call the reusable dialog function
    }
  }

  Widget _buildStatItem(String label, String value, IconData icon, MaterialColor color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color[50],  // Lighter shade of the color
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: color[700],  // Darker shade for the icon
            size: 24,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: GoogleFonts.cairo(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: GoogleFonts.cairo(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildDonationStats() {
    // Calculate total donations
    final totalAmount = donations.fold<double>(
        0, (sum, donation) => sum + (donation['amount'] as num));
    final totalCount = donations.length;
    final recurringCount = donations.where((d) => d['isRecurring']).length;

    return FadeInUp(
      duration: const Duration(milliseconds: 600),
      child: Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatItem(
                  "إجمالي التبرعات",
                  "$totalAmount ريال",
                  Iconsax.money_tick,
                  Colors.green,
                ),
                _buildStatItem(
                  "عدد التبرعات",
                  "$totalCount",
                  Iconsax.chart_success,
                  Colors.blue,
                ),
              ],
            ),

          ],
        ),
      ),
    );
  }

  Widget _buildDonationsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: donations.length,
      itemBuilder: (context, index) {
        final donation = donations[index];
        return _buildDonationCard(donation);
      },
    );
  }

  Widget _buildDonationCard(Map<String, dynamic> donation) {
    return FadeInUp(
      duration: Duration(milliseconds: 500 + (donations.indexOf(donation) * 100)),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Container(
          padding: const EdgeInsets.all(16),
          margin: const EdgeInsets.only(bottom: 16), // Add margin if needed
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 5,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(donation['icon'], color: Colors.green[700]),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${donation['amount']} ريال",
                      style: GoogleFonts.cairo(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      intl.DateFormat('dd/MM/yyyy').format(donation['date']),
                      style: GoogleFonts.cairo(
                        fontSize: 12,
                        color: Colors.grey[500],
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.green[50],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      donation['status'],
                      style: GoogleFonts.cairo(
                        fontSize: 12,
                        color: Colors.green[700],
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}