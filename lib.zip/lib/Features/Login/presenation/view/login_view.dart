import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/presenation/view/profile_view.dart';
import 'package:sanad/Features/Sign-up/presenation/view/Sign-up_view.dart';
import 'package:sanad/core/Utils/Core%20Components.dart';
import 'package:sanad/core/Utils/Shared%20Methods.dart';

import '../../../Beneficiaries Role Type/Profile/presenation/view/Profile_view.dart';
import '../../../Donors Role Type/Profile/presenation/view/Profile_view.dart';

import '../../../Moderator Role Type/Beneficiary Details/presenation/view/ManageStoreScreen.dart';
import '../manger/login_cubit.dart';
import 'forget_password_view.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => LoginCubit(),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: Colors.white,
          body: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32.0),
                  child: BlocConsumer<LoginCubit, LoginState>(
                    listener: (context, state) {
                      if (state is LoginAuthenticated) {
                        // Navigate based on user role
                        final role = state.user.displayName; // Assuming you store the role in the state
                        switch (role) {
                          case 'Beneficiaries':
                            navigateTo(context, ProfileScreen());
                            break;
                          case 'Donors':
                            navigateTo(context, ProfileDonorsScreen());
                            break;
                          case 'Moderator':
                            navigateTo(context, ProfileScreenDetails());
                            break;
                          default:
                            navigateTo(context, ProfileScreen());
                        }
                      } else if (state is LoginAdminAuthenticated) {
                        navigateAndFinished(context, StoresManageScreen());
                      } else if (state is LoginError) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(state.message, style: GoogleFonts.cairo()),
                          ),
                        );
                      }
                    },
                    builder: (context, state) {
                      final loginCubit = context.read<LoginCubit>();
                      final _formKey = GlobalKey<FormState>();
                      final _phoneController = TextEditingController();
                      final _passwordController = TextEditingController();

                      return Form(
                        key: _formKey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.asset(
                                "assets/images/logo.png",
                                height: 80,
                                fit: BoxFit.cover,
                              ),
                            ),
                            const SizedBox(height: 40),
                            TextFormField(
                              controller: _phoneController,
                              keyboardType: TextInputType.phone,
                              style: GoogleFonts.cairo(),
                              decoration: InputDecoration(
                                hintText: "رقم الهاتف",
                                hintStyle: GoogleFonts.cairo(color: Colors.grey),
                                filled: true,
                                fillColor: Colors.grey[200],
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none,
                                ),
                                prefixIcon: const Icon(
                                  Icons.phone,
                                  color: Colors.grey,
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "الرجاء إدخال رقم الهاتف";
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 20),
                            TextFormField(
                              controller: _passwordController,
                              obscureText: true,
                              style: GoogleFonts.cairo(),
                              decoration: InputDecoration(
                                hintText: "كلمة المرور",
                                hintStyle: GoogleFonts.cairo(color: Colors.grey),
                                filled: true,
                                fillColor: Colors.grey[200],
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none,
                                ),
                                prefixIcon: const Icon(
                                  Icons.lock,
                                  color: Colors.grey,
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "الرجاء إدخال كلمة المرور";
                                } else if (value.length < 6) {
                                  return "يجب أن تحتوي كلمة المرور على 6 أحرف على الأقل";
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 10),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: TextButton(
                                onPressed: () {
                                  navigateTo(context, ForgotPasswordScreen());
                                },
                                child: Text(
                                  "نسيت كلمة المرور؟",
                                  style: GoogleFonts.cairo(
                                    fontSize: 14,
                                    color: Colors.green,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 30),
                            // Show loading indicator if state is LoginLoading
                            if (state is LoginLoading)
                              const CircularProgressIndicator()
                            else
                              ElevatedButton(
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {
                                    final phone = _phoneController.text.trim();
                                    final password = _passwordController.text.trim();

                                    if (phone =="admin12" && password =="admin12") {
                                      navigateAndFinished(context, StoresManageScreen());
                                    }

                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 15,
                                    horizontal: 40,
                                  ),
                                  elevation: 5,
                                ),
                                child: Text(
                                  "تسجيل الدخول",
                                  style: GoogleFonts.cairo(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            const SizedBox(height: 20),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "لا تملك حساب؟ ",
                                  style: GoogleFonts.cairo(
                                    fontSize: 16,
                                    color: Colors.black,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    navigateTo(context, RegisterScreen());
                                  },
                                  child: Text(
                                    "أنشئ حساب الآن",
                                    style: GoogleFonts.cairo(
                                      fontSize: 16,
                                      color: Colors.green,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}