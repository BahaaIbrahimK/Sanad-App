import 'package:bloc/bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:meta/meta.dart';

part 'login_state.dart';

class LoginCubit extends Cubit<LoginState> {
  LoginCubit() : super(LoginInitial());

  final FirebaseAuth _auth = FirebaseAuth.instance;
  String? _verificationId; // Store the verification ID for OTP verification

  // Login with phone number and password
  Future<void> login({
    required String phoneNumber,
    required String password,
    bool isAdmin = false, // Optional: Add admin login logic
  }) async {
    emit(LoginLoading());
    try {
      // Validate inputs
      if (phoneNumber.isEmpty || password.isEmpty) {
        emit(LoginError('Phone number and password are required.'));
        return;
      }

      // Hardcoded admin check (optional)
      if (isAdmin && phoneNumber == "admin12" && password == "admin12") {
        emit(LoginAdminAuthenticated());
        return;
      }



      // Sign in with Firebase Auth
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: '$phoneNumber@example.com', // Replace with your email logic
        password: password,
      );

      // Emit authenticated state
      emit(LoginAuthenticated(userCredential.user!));
    } on FirebaseAuthException catch (e) {
      emit(LoginError(e.message ?? 'Login failed. Please try again.'));
    } catch (e) {
      emit(LoginError('An error occurred: $e'));
    }
  }

  // Send OTP to the user's phone number
  Future<void> sendOtp({required String phoneNumber}) async {
    emit(ForgetPasswordLoading());
    try {
      // Validate input
      if (phoneNumber.isEmpty) {
        emit(ForgetPasswordError('Phone number is required.'));
        return;
      }

      if (!RegExp(r"^\+?[0-9]{10,15}$").hasMatch(phoneNumber)) {
        emit(ForgetPasswordError('Please enter a valid phone number with country code.'));
        return;
      }

      // Send OTP to the phone number
      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Auto-sign-in if the OTP is verified automatically (e.g., on Android devices)
          await _auth.signInWithCredential(credential);
          emit(ForgetPasswordOtpSent());
        },
        verificationFailed: (FirebaseAuthException e) {
          emit(ForgetPasswordError(e.message ?? 'Failed to send OTP. Please try again.'));
        },
        codeSent: (String verificationId, int? resendToken) {
          _verificationId = verificationId; // Store the verification ID
          emit(ForgetPasswordOtpSent());
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          _verificationId = verificationId; // Handle timeout if needed
        },
      );
    } catch (e) {
      emit(ForgetPasswordError('An error occurred: $e'));
    }
  }

  // Verify OTP and reset password
  Future<void> verifyOtpAndResetPassword({
    required String otp,
    required String newPassword,
  }) async {
    emit(ForgetPasswordLoading());
    try {
      // Validate input
      if (otp.isEmpty || newPassword.isEmpty) {
        emit(ForgetPasswordError('OTP and new password are required.'));
        return;
      }

      if (newPassword.length < 6) {
        emit(ForgetPasswordError('Password must be at least 6 characters long.'));
        return;
      }

      // Create a PhoneAuthCredential with the OTP
      final credential = PhoneAuthProvider.credential(
        verificationId: _verificationId!,
        smsCode: otp,
      );

      // Sign in with the credential
      final userCredential = await _auth.signInWithCredential(credential);

      // Update the user's password
      await userCredential.user!.updatePassword(newPassword);

      emit(ForgetPasswordSuccess());
    } on FirebaseAuthException catch (e) {
      emit(ForgetPasswordError(e.message ?? 'Failed to verify OTP or reset password.'));
    } catch (e) {
      emit(ForgetPasswordError('An error occurred: $e'));
    }
  }

  // Logout the user
  Future<void> logout() async {
    try {
      await _auth.signOut();
      emit(LoginUnauthenticated());
    } catch (e) {
      emit(LoginError('Failed to logout. Please try again.'));
    }
  }
}