part of 'login_cubit.dart';

@immutable
abstract class LoginState {}

class LoginInitial extends LoginState {}

class LoginLoading extends LoginState {}

class LoginAuthenticated extends LoginState {
  final User user;
  LoginAuthenticated(this.user);
}
class LoginAdminAuthenticated extends LoginState {
  LoginAdminAuthenticated();
}

class LoginUnauthenticated extends LoginState {}

class LoginError extends LoginState {
  final String message;
  LoginError(this.message);
}


class ForgetPasswordLoading extends LoginState {}

class ForgetPasswordOtpSent extends LoginState {}

class ForgetPasswordSuccess extends LoginState {}

class ForgetPasswordError extends LoginState {
  final String message;
  ForgetPasswordError(this.message);
}