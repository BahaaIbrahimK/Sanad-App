class UserModel {
  String name;
  String email;
  String phoneNumber;
  String region;
  String userType;
  String joinDate;
  String image;

  UserModel({
    required this.name,
    required this.email,
    required this.phoneNumber,
    required this.region,
    required this.userType,
    required this.joinDate,
    required this.image,
  });

  // Factory constructor to create a UserModel from a JSON map
  factory UserModel.fromJson(Map<String, String> json) {
    return UserModel(
      name: json['Name'] ?? '',
      email: json['Email'] ?? '',
      phoneNumber: json['Phone Number'] ?? '',
      region: json['Region'] ?? '',
      userType: json['User Type'] ?? '',
      joinDate: json['Join Date'] ?? '',
      image: json["image"] ?? '',
    );
  }

  // Method to convert a UserModel to a JSON map
  Map<String, String> toJson() {
    return {
      'Name': name,
      'Email': email,
      "image":image,
      'Phone Number': phoneNumber,
      'Region': region,
      'User Type': userType,
      'Join Date': joinDate,
    };
  }
}
