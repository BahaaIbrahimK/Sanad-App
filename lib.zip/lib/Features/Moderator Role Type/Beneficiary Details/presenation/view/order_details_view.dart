import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/data/order_model.dart';
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/presenation/view/ManageStoreScreen.dart';
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/presenation/view/arrange_orders_view.dart';
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/presenation/view/beneficiary_evaluation_view.dart';
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/presenation/view/profile_view.dart';
import 'package:sanad/core/Utils/signoutMessage.dart';

class OrderDetailsView extends StatefulWidget {
  final OrderModelData orderModelData;

   const OrderDetailsView({super.key, required this.orderModelData});

  @override
  State<OrderDetailsView> createState() => _OrderDetailsViewState();
}

class _OrderDetailsViewState extends State<OrderDetailsView> {
  bool _isEditing = false;
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _familyCountController = TextEditingController();
  final TextEditingController _incomeController = TextEditingController();
  final TextEditingController _housingController = TextEditingController();
  final TextEditingController _paidController = TextEditingController();
  final TextEditingController _difficultyController = TextEditingController();


  @override
  void initState() {
    _nameController.text =widget.orderModelData.name;
    _familyCountController.text =widget.orderModelData.numberOfMembers.toString();
    _incomeController.text =widget.orderModelData.monthlyIncome;
    _housingController.text =widget.orderModelData.housingCondition;
    _paidController.text =widget.orderModelData.monthlyIncome;
    _difficultyController.text =widget.orderModelData.states;
    super.initState();
  }
  @override
  void dispose() {
    _nameController.dispose();
    _familyCountController.dispose();
    _incomeController.dispose();
    _housingController.dispose();
    _paidController.dispose();
    _difficultyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        body: SafeArea(
          child: Stack(
            children: [
              SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Back Button
                        _buildAppBar(context),
                        SizedBox(height: 20,),
                        // Beautiful Header
                        FadeInDown(
                          duration: const Duration(milliseconds: 500),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.green.shade400,
                                  Colors.green.shade600,
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.green.withOpacity(0.2),
                                  blurRadius: 15,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'تفاصيل الطلب',
                                          style: GoogleFonts.cairo(
                                            color: Colors.white,
                                            fontSize: 26,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          'مراجعة بيانات الطلب',
                                          style: GoogleFonts.cairo(
                                            color: Colors.white.withOpacity(0.9),
                                            fontSize: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 25),

                        // Profile Image Section
                        FadeInUp(
                          duration: const Duration(milliseconds: 600),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.04),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Stack(
                                  alignment: Alignment.bottomRight,
                                  children: [
                                    Container(
                                      width: 120,
                                      height: 120,
                                      decoration: BoxDecoration(
                                        color: Colors.grey[200],
                                        shape: BoxShape.circle,
                                        image: const DecorationImage(
                                          image: AssetImage('assets/images/woman.png'),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                    if (_isEditing)
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Colors.green[600],
                                          shape: BoxShape.circle,
                                        ),
                                        child: IconButton(
                                          icon: const Icon(
                                            Icons.camera_alt_rounded,
                                            color: Colors.white,
                                            size: 20,
                                          ),
                                          onPressed: () {
                                            // Implement image picker
                                          },
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'صورة المستفيد',
                                  style: GoogleFonts.cairo(
                                    fontSize: 16,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 25),

                        // Information Fields
                        FadeInUp(
                          duration: const Duration(milliseconds: 700),
                          child: _buildEditableField(
                            'اسم المستفيد',
                            Icons.person_rounded,
                            _nameController,
                                (value) => value!.isEmpty ? 'لا يوجد' : null,
                          ),
                        ),

                        FadeInUp(
                          duration: const Duration(milliseconds: 800),
                          child: _buildEditableField(
                            'تعداد الأسرة',
                            Icons.family_restroom_rounded,
                            _familyCountController,
                                (value) => value!.isEmpty ? 'لا يوجد' : null,
                          ),
                        ),

                        FadeInUp(
                          duration: const Duration(milliseconds: 900),
                          child: _buildEditableField(
                            'الدخل الشهري',
                            Icons.account_balance_wallet_rounded,
                            _incomeController,
                                (value) => value!.isEmpty ? 'لا يوجد' : null,
                          ),
                        ),
                        FadeInUp(
                          duration: const Duration(milliseconds: 1000),
                          child: _buildEditableField(
                            'حالة السكن',
                            Icons.home_rounded,
                            _housingController,
                                (value) => value!.isEmpty ? 'الرجاء إدخال وصف حالة السكن' : null,
                          ),
                        ),

                        FadeInUp(
                          duration: const Duration(milliseconds: 1000),
                          child: _buildEditableField(
                            'الدخل المستحق',
                            Icons.home_rounded,
                            _paidController,
                                (value) => value!.isEmpty ? 'لا يوجد' : null,
                          ),
                        ),

                        FadeInUp(
                          duration: const Duration(milliseconds: 1000),
                          child: _buildEditableField(
                            'حالة الاستحقاق',
                            Icons.home_rounded,
                            _difficultyController,
                                (value) => value!.isEmpty ? 'لا يوجد' : null,
                          ),
                        ),


                        const SizedBox(height: 30),

                        // Upload Documents Section
                        FadeInUp(
                          duration: const Duration(milliseconds: 1100),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.04),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'تحميل المستندات',
                                  style: GoogleFonts.cairo(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey[800],
                                  ),
                                ),
                                const SizedBox(height: 16),
                                GridView.count(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  crossAxisCount: 3,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10,
                                  children: [
                                    _buildDocumentUploadButton('الهوية الوطنية'),
                                    _buildDocumentUploadButton('إثبات الدخل'),
                                    _buildDocumentUploadButton('عقد الإيجار'),
                                    _buildDocumentUploadButton('مستندات أخرى'),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 30),

                        // Action Buttons
                        if (!_isEditing)
                          FadeInUp(
                            duration: const Duration(milliseconds: 1200),
                            child: Row(
                              children: [
                                Expanded(
                                  child: _buildActionButton(
                                    'طلب مستندات',
                                    Colors.green.shade500,
                                    Icons.picture_as_pdf,
                                        () {
                                          _showApprovalDialog();
                                        },
                                  ),
                                ),
                                const SizedBox(width: 15),
                                Expanded(
                                  child: _buildActionButton(
                                    'ارسال اشعارات',
                                    Colors.green.shade500,
                                    Icons.notification_add,
                                        () {
                                          _showNotiDialog();
                                        },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _buildAppBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildMenu(context),
          Image.asset(
            "assets/images/logo.png",
            height: 70,
            fit: BoxFit.contain,
          ),
        ],
      ),
    );
  }

  Widget _buildMenu(BuildContext context) {
    return PopupMenuButton<String>(
      icon: Icon(Icons.menu, size: 28, color: Colors.green[700]),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      color: Colors.green[700],
      elevation: 8,
      offset: const Offset(0, 40),
      itemBuilder: (BuildContext context) => [
        _buildMenuItem("الملف الشخصي", "profile", Icons.person),
        _buildMenuItem("تقييم الطلبات الجديده", "evaluate_accounts", Icons.account_balance_wallet),
        _buildMenuItem("طلبات المستفيدين المقبوله", "organize_shipments", Icons.receipt_long),
        _buildMenuItem("ادارة المتاجر", "market", Icons.shopping_cart),
        _buildMenuItem("تسجيل الخروج", "logout", Icons.logout),
      ],
      onSelected: (value) => _handleMenuSelection(context, value),
    );
  }

  void _handleMenuSelection(BuildContext context, String value) {
    final routes = {
      "evaluate_accounts": () => BeneficiaryEvaluationScreen(),
      "organize_shipments": () => ArrangeOrdersScreen(),
      "profile": () => ProfileScreenDetails(),
      "market": () => StoresManageScreen(),
    };

    if (routes.containsKey(value)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => routes[value]!()),
      );
    } else if (value == "logout") {
      showSignOutDialog(context);
    }
  }

  PopupMenuItem<String> _buildMenuItem(String text, String value, IconData icon) {
    return PopupMenuItem<String>(
      value: value,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              text,
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(width: 12),
            Icon(icon, color: Colors.white, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildEditableField(
      String label,
      IconData icon,
      TextEditingController controller,
      String? Function(String?) validator,
      ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.green[600], size: 22),
              const SizedBox(width: 12),
              Text(
                label,
                style: GoogleFonts.cairo(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _isEditing
              ? TextFormField(
            controller: controller,
            validator: validator,
            style: GoogleFonts.cairo(
              fontSize: 15,
              color: Colors.grey[700],
            ),
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.grey[50],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.grey.shade200),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.grey.shade200),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.green.shade400),
              ),
              contentPadding: const EdgeInsets.all(16),
            ),
          )
              : Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Text(
              controller.text,
              style: GoogleFonts.cairo(
                fontSize: 15,
                color: Colors.grey[700],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(
      String text,
      Color color,
      IconData icon,
      VoidCallback onPressed,
      ) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        elevation: 2,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.white, size: 22),
          const SizedBox(width: 10),
          Text(
            text,
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }


// Helper method to build detail rows
  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        children: [
          Icon(Icons.info_outline, color: Colors.green[600], size: 20),
          const SizedBox(width: 10),
          Text(
            '$label: ',
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: GoogleFonts.cairo(
                color: Colors.grey[700],
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

// Helper method to build list details
  Widget _buildListDetail(String key, List values) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.list, color: Colors.green[600], size: 20),
              const SizedBox(width: 10),
              Text(
                _getLocalizedKey(key) + ': ',
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
            ],
          ),
          ...values.map((value) => Padding(
            padding: const EdgeInsets.only(right: 30.0, top: 4),
            child: Text(
              '• $value',
              style: GoogleFonts.cairo(
                color: Colors.grey[700],
              ),
            ),
          )).toList(),
        ],
      ),
    );
  }

// Localization helper for keys
  String _getLocalizedKey(String key) {
    final Map<String, String> keyTranslations = {
      'fullName': 'الاسم الكامل',
      'nationalID': 'رقم الهوية',
      'dateOfBirth': 'تاريخ الميلاد',
      'placeOfBirth': 'مكان الميلاد',
      'nationality': 'الجنسية',
      'maritalStatus': 'الحالة الاجتماعية',
      'address': 'العنوان',
      'phoneNumber': 'رقم الهاتف',
      'email': 'البريد الإلكتروني',
      'jobTitle': 'المسمى الوظيفي',
      'employer': 'جهة العمل',
      'monthlyIncome': 'الدخل الشهري',
      'employmentDate': 'تاريخ التعيين',
      'workLocation': 'موقع العمل',
      'employmentType': 'نوع التوظيف',
      'socialInsuranceNumber': 'رقم التأمين الاجتماعي',
      'taxIdentificationNumber': 'الرقم الضريبي',
      'propertyType': 'نوع العقار',
      'rentAmount': 'قيمة الإيجار',
      'leaseStartDate': 'تاريخ بداية العقد',
      'leaseEndDate': 'تاريخ انتهاء العقد',
      'landlordName': 'اسم المالك',
      'propertyLocation': 'موقع العقار',
      'propertySize': 'مساحة العقار',
      'bedroomCount': 'عدد غرف النوم',
      'contractStatus': 'حالة العقد',
      'educationLevel': 'المستوى التعليمي',
      'degree': 'التخصص',
      'university': 'الجامعة',
      'graduationYear': 'سنة التخرج',
      'additionalCertificates': 'الشهادات الإضافية',
      'healthStatus': 'الحالة الصحية',
      'familyMembers': 'عدد أفراد الأسرة',
    };

    return keyTranslations[key] ?? key;
  }

  void _showUserDetailsPopup(BuildContext context, String documentType) {
    // Map of document types with corresponding user details
    final Map<String, Map<String, dynamic>> userDetails = {
      'الهوية الوطنية': {
        'fullName': 'فاطمة محمد العبدلي',
        'nationalID': '1234567890',
        'dateOfBirth': '15/03/1990',
        'placeOfBirth': 'الرياض, المملكة العربية السعودية',
        'nationality': 'سعودية',
        'maritalStatus': 'متزوجة',
        'address': 'حي الملك فهد, الرياض',
        'phoneNumber': '+966 55 123 4567',
        'email': 'fatima.abdali@example.com',
        'profileImage': 'assets/images/woman.png',
      },
      'إثبات الدخل': {
        'jobTitle': 'موظفة حكومية',
        'employer': 'وزارة التعليم',
        'monthlyIncome': '12,500 ريال',
        'employmentDate': '01/01/2015',
        'workLocation': 'الرياض',
        'employmentType': 'دوام كامل',
        'socialInsuranceNumber': '9876543210',
        'taxIdentificationNumber': 'TAX-123456',
      },
      'عقد الإيجار': {
        'propertyType': 'شقة سكنية',
        'rentAmount': '4,500 ريال شهرياً',
        'leaseStartDate': '01/09/2023',
        'leaseEndDate': '31/08/2024',
        'landlordName': 'خالد محمد الشريف',
        'propertyLocation': 'حي السلام, الرياض',
        'propertySize': '120 متر مربع',
        'bedroomCount': '3 غرف',
        'contractStatus': 'ساري المفعول',
      },
      'مستندات أخرى': {
        'educationLevel': 'بكالوريوس',
        'degree': 'هندسة حاسب آلي',
        'university': 'جامعة الملك سعود',
        'graduationYear': '2014',
        'additionalCertificates': [
          'شهادة CCNA',
          'دورة إدارة المشاريع',
        ],
        'healthStatus': 'لا توجد حالات مرضية مزمنة',
        'familyMembers': '4 أفراد',
      },
    };

    // Get details for the specific document type
    final details = userDetails[documentType] ?? {};

    showDialog(
      context: context,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'تفاصيل المستند: $documentType',
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
                color: Colors.green[800],
              ),
              textAlign: TextAlign.center,
            ),
            content: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Dynamic details based on document type
                  ...details.entries.map((entry) {
                    // Handle list type separately
                    if (entry.value is List) {
                      return _buildListDetail(entry.key, entry.value);
                    }
                    return _buildDetailRow(
                        _getLocalizedKey(entry.key),
                        entry.value.toString()
                    );
                  }).toList(),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text(
                  'إغلاق',
                  style: GoogleFonts.cairo(
                    color: Colors.green[700],
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

// Helper method to build detail rows


// Update the _buildDocumentUploadButton method
  Widget _buildDocumentUploadButton(String label) {
    return GestureDetector(
      onTap: () {
        _showUserDetailsPopup(context, label);
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[50],
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: Colors.grey[300]!,
            width: 1.5,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.download, color: Colors.green[600], size: 30),
            const SizedBox(height: 10),
            Text(
              label,
              style: GoogleFonts.cairo(
                fontSize: 12,
                color: Colors.grey[700],
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
  void _saveChanges() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'تم حفظ التغييرات بنجاح',
          style: GoogleFonts.cairo(),
          textAlign: TextAlign.right,
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.all(10),
      ),
    );
  }


  void _showApprovalDialog() {
    TextEditingController amountController = TextEditingController();
    TextEditingController dataController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl, // Ensure full RTL support
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: StatefulBuilder(
              builder: (context, setState) {
                return Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title
                      Center(
                        child: Text(
                          'طلب مستندات جديده',
                          style: GoogleFonts.cairo(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey[800],
                          ),
                          textAlign: TextAlign.right,
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Monthly Amount Field
                      Text(
                        'أدخل اسم الملف المطلوب',
                        style: GoogleFonts.cairo(fontSize: 16, color: Colors.grey[700]),
                        textAlign: TextAlign.right,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: amountController,
                        keyboardType: TextInputType.text,
                        textAlign: TextAlign.right, // Align input text right
                        style: GoogleFonts.cairo(fontSize: 16),
                        decoration: InputDecoration(
                          hintText: 'مستند تقرير طبي', // Default hint
                          hintStyle: GoogleFonts.cairo(color: Colors.grey[400]),
                          filled: true,
                          fillColor: Colors.grey[50],
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.grey.shade300),
                          ),
                          contentPadding: const EdgeInsets.all(14),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Beneficiary Status Selection
                      Text(
                        'تاريخ التسليم الأدني',
                        style: GoogleFonts.cairo(fontSize: 16, color: Colors.grey[700]),
                        textAlign: TextAlign.right,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: dataController,
                        keyboardType: TextInputType.datetime,
                        textAlign: TextAlign.right, // Align input text right
                        style: GoogleFonts.cairo(fontSize: 16),
                        decoration: InputDecoration(
                          hintText: '16/2/2025', // Default hint
                          hintStyle: GoogleFonts.cairo(color: Colors.grey[400]),
                          filled: true,
                          fillColor: Colors.grey[50],
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.grey.shade300),
                          ),
                          contentPadding: const EdgeInsets.all(14),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Action Buttons
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                if (amountController.text.isNotEmpty && dataController.text.isNotEmpty) {
                                  Navigator.pop(context);
                                  _acceptorder();
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'يرجى ملء جميع الحقول',
                                        style: GoogleFonts.cairo(),
                                        textAlign: TextAlign.right,
                                      ),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green.shade500,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                              child: Text(
                                'تأكيد',
                                style: GoogleFonts.cairo(
                                  fontSize: 16,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => Navigator.pop(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red.shade500,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                              child: Text(
                                'إلغاء',
                                style: GoogleFonts.cairo(
                                  fontSize: 16,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  void _showNotiDialog() {
    TextEditingController notificationController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl, // Ensure full RTL support
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: StatefulBuilder(
              builder: (context, setState) {
                return Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title
                      Center(
                        child: Text(
                          'ارسال اشعار للمستفيد',
                          style: GoogleFonts.cairo(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey[800],
                          ),
                          textAlign: TextAlign.right,
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Monthly Amount Field
                      Text(
                        'ادخل الاشعار المطلوب ارساله',
                        style: GoogleFonts.cairo(fontSize: 16, color: Colors.grey[700]),
                        textAlign: TextAlign.right,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: notificationController,
                        keyboardType: TextInputType.text,
                        textAlign: TextAlign.right, // Align input text right
                        style: GoogleFonts.cairo(fontSize: 16),
                        decoration: InputDecoration(
                          hintText: 'سبق تم زيارتكم للمنزل ولم يتواجد أحد!.', // Default hint
                          hintStyle: GoogleFonts.cairo(color: Colors.grey[400]),
                          filled: true,
                          fillColor: Colors.grey[50],
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.grey.shade300),
                          ),
                          contentPadding: const EdgeInsets.all(14),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Action Buttons
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                if (notificationController.text.isNotEmpty) {
                                  Navigator.pop(context);
                                    _sendNoti();
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'يرجى ملء جميع الحقول',
                                        style: GoogleFonts.cairo(),
                                        textAlign: TextAlign.right,
                                      ),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green.shade500,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                              child: Text(
                                'ارسال',
                                style: GoogleFonts.cairo(
                                  fontSize: 16,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => Navigator.pop(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red.shade500,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                              child: Text(
                                'إلغاء',
                                style: GoogleFonts.cairo(
                                  fontSize: 16,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }


  void _acceptorder() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'تم قبول الطلب بنجاح',
          style: GoogleFonts.cairo(),
          textAlign: TextAlign.right,
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.all(10),
      ),
    );
  }

  void _sendNoti() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'تم ارسال الاشعار بنجاح',
          style: GoogleFonts.cairo(),
          textAlign: TextAlign.right,
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.all(10),
      ),
    );
  }




}