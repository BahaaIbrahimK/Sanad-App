import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/presenation/view/profile_view.dart';

import '../../../../../core/Utils/signoutMessage.dart';
import '../../data/order_model.dart';
import '../manger/Orders/orders_cubit.dart';
import '../manger/Orders/orders_state.dart';
import 'ManageStoreScreen.dart';
import 'arrange_orders_view.dart';
import 'beneficiary_evaluation_view.dart';

class Document {
  final String title;
  final String description;
  final String filePath;
  final String uploadDate; // New field
  final String fileSize; // New field
  final String status; // New field
  final String notes; // New field

  Document({
    required this.title,
    required this.description,
    required this.filePath,
    required this.uploadDate,
    required this.fileSize,
    required this.status,
    required this.notes,
  });
}

class BeneficiaryDetailsScreen extends StatefulWidget {
  final OrderModelData orderModelData;
  const BeneficiaryDetailsScreen({super.key, required this.orderModelData});

  @override
  State<BeneficiaryDetailsScreen> createState() =>
      _BeneficiaryDetailsScreenState();
}

class _BeneficiaryDetailsScreenState extends State<BeneficiaryDetailsScreen> {
  bool _isEditing = false;
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _familyCountController = TextEditingController();
  final TextEditingController _incomeController = TextEditingController();
  final TextEditingController _housingController = TextEditingController();

  // List of documents with additional details
  final List<Document> documents = [
    Document(
      title: 'الهوية الوطنية',
      description: 'صورة من الهوية الوطنية للمستفيد.',
      filePath: 'assets/documents/national_id.pdf',
      uploadDate: '2023-10-01',
      fileSize: '2.5 MB',
      status: 'مقبول',
      notes: 'تم التحقق من الهوية بواسطة الإدارة.',
    ),
    Document(
      title: 'إثبات الدخل',
      description: 'وثيقة تثبت الدخل الشهري للمستفيد.',
      filePath: 'assets/documents/income_proof.pdf',
      uploadDate: '2023-10-02',
      fileSize: '1.8 MB',
      status: 'قيد المراجعة',
      notes: 'يجب التحقق من الوثيقة مع \nالجهات المختصة.',
    ),
    Document(
      title: 'عقد الإيجار',
      description: 'عقد إيجار السكن الحالي للمستفيد.',
      filePath: 'assets/documents/rent_contract.pdf',
      uploadDate: '2023-10-03',
      fileSize: '3.2 MB',
      status: 'مرفوض',
      notes: 'العقد غير واضح ويحتاج \nإلى إعادة رفعه.',
    ),
    Document(
      title: 'مستندات أخرى',
      description: 'أي مستندات إضافية مطلوبة.',
      filePath: 'assets/documents/other_documents.pdf',
      uploadDate: '2023-10-04',
      fileSize: '1.1 MB',
      status: 'مقبول',
      notes: 'تمت الموافقة على \nالمستندات الإضافية.',
    ),
  ];

  @override
  void initState() {
    _nameController.text = widget.orderModelData.name;
    _familyCountController.text =
        widget.orderModelData.numberOfMembers.toString();
    _incomeController.text = widget.orderModelData.monthlyIncome;
    _housingController.text = widget.orderModelData.housingCondition;
    super.initState();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _familyCountController.dispose();
    _incomeController.dispose();
    _housingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<OrderCubit, OrderState>(
      listener: (context, state) {
        if (state is OrderUpdated) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'تم تحديث الطلب بنجاح',
                style: GoogleFonts.cairo(),
                textAlign: TextAlign.right,
              ),
              backgroundColor: Colors.green,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              margin: const EdgeInsets.all(10),
            ),
          );
        } else if (state is OrderError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'حدث خطأ: ${state.message}',
                style: GoogleFonts.cairo(),
                textAlign: TextAlign.right,
              ),
              backgroundColor: Colors.red,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              margin: const EdgeInsets.all(10),
            ),
          );
        }
      },
      builder: (context, state) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            backgroundColor: Colors.grey[50],
            body: SafeArea(
              child: Stack(
                children: [
                  SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            // Back Button
                            _buildAppBar(context),
                            const SizedBox(height: 20),

                            // Beautiful Header
                            FadeInDown(
                              duration: const Duration(milliseconds: 500),
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.green.shade400,
                                      Colors.green.shade600,
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.green.withOpacity(0.2),
                                      blurRadius: 15,
                                      offset: const Offset(0, 5),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'تفاصيل الطلب',
                                              style: GoogleFonts.cairo(
                                                color: Colors.white,
                                                fontSize: 26,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            const SizedBox(height: 8),
                                            Text(
                                              'مراجعة بيانات الطلب',
                                              style: GoogleFonts.cairo(
                                                color: Colors.white
                                                    .withOpacity(0.9),
                                                fontSize: 16,
                                              ),
                                            ),
                                          ],
                                        ),
                                        Container(
                                          decoration: BoxDecoration(
                                            color: Colors.white.withOpacity(0.2),
                                            borderRadius: BorderRadius.circular(15),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            const SizedBox(height: 25),

                            // Profile Image Section
                            FadeInUp(
                              duration: const Duration(milliseconds: 600),
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.04),
                                      blurRadius: 10,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  children: [
                                    Stack(
                                      alignment: Alignment.bottomRight,
                                      children: [
                                        Container(
                                          width: 120,
                                          height: 120,
                                          decoration: BoxDecoration(
                                            color: Colors.grey[200],
                                            shape: BoxShape.circle,
                                            image: const DecorationImage(
                                              image: AssetImage(
                                                  'assets/images/woman.png'),
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        if (_isEditing)
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Colors.green[600],
                                              shape: BoxShape.circle,
                                            ),
                                            child: IconButton(
                                              icon: const Icon(
                                                Icons.camera_alt_rounded,
                                                color: Colors.white,
                                                size: 20,
                                              ),
                                              onPressed: () {
                                                // Implement image picker
                                              },
                                            ),
                                          ),
                                      ],
                                    ),
                                    const SizedBox(height: 16),
                                    Text(
                                      'صورة المستفيد',
                                      style: GoogleFonts.cairo(
                                        fontSize: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            const SizedBox(height: 25),

                            // Information Fields
                            FadeInUp(
                              duration: const Duration(milliseconds: 700),
                              child: _buildEditableField(
                                'اسم المستفيد',
                                Icons.person_rounded,
                                _nameController,
                                    (value) => value!.isEmpty
                                    ? 'الرجاء إدخال الاسم'
                                    : null,
                              ),
                            ),

                            FadeInUp(
                              duration: const Duration(milliseconds: 800),
                              child: _buildEditableField(
                                'تعداد الأسرة',
                                Icons.family_restroom_rounded,
                                _familyCountController,
                                    (value) => value!.isEmpty
                                    ? 'الرجاء إدخال تعداد الأسرة'
                                    : null,
                              ),
                            ),

                            FadeInUp(
                              duration: const Duration(milliseconds: 900),
                              child: _buildEditableField(
                                'الدخل الشهري',
                                Icons.account_balance_wallet_rounded,
                                _incomeController,
                                    (value) => value!.isEmpty
                                    ? 'الرجاء إدخال الدخل الشهري'
                                    : null,
                              ),
                            ),

                            FadeInUp(
                              duration: const Duration(milliseconds: 1000),
                              child: _buildEditableField(
                                'حالة السكن',
                                Icons.home_rounded,
                                _housingController,
                                    (value) => value!.isEmpty
                                    ? 'الرجاء إدخال وصف حالة السكن'
                                    : null,
                              ),
                            ),

                            const SizedBox(height: 25),

                            // Document Upload Section
                            FadeInUp(
                              duration: const Duration(milliseconds: 1100),
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.04),
                                      blurRadius: 10,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'تحميل المستندات',
                                      style: GoogleFonts.cairo(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.grey[800],
                                      ),
                                    ),
                                    const SizedBox(height: 16),
                                    GridView.count(
                                      shrinkWrap: true,
                                      physics:
                                      const NeverScrollableScrollPhysics(),
                                      crossAxisCount: 3,
                                      crossAxisSpacing: 10,
                                      mainAxisSpacing: 10,
                                      children: documents
                                          .map((doc) => _buildDocumentUploadButton(doc))
                                          .toList(),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            const SizedBox(height: 16),

                            // Action Buttons
                            FadeInUp(
                              duration: const Duration(milliseconds: 1200),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: _buildActionButton(
                                      'قبول الطلب',
                                      Colors.green.shade500,
                                      Icons.check_circle_rounded,
                                          () {
                                        _showApprovalDialog(context);
                                      },
                                    ),
                                  ),
                                  const SizedBox(width: 15),
                                  Expanded(
                                    child: _buildActionButton(
                                      'رفض الطلب',
                                      Colors.red.shade500,
                                      Icons.cancel_rounded,
                                          () {
                                        _showRejectReasonDialog(context);
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDocumentUploadButton(Document document) {
    return GestureDetector(
      onTap: () {
        _showDocumentDetailsDialog(context, document);
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[50],
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: Colors.grey[300]!, width: 1.5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.download, color: Colors.green[600], size: 30),
            const SizedBox(height: 10),
            Text(
              document.title,
              style: GoogleFonts.cairo(
                fontSize: 12,
                color: Colors.grey[700],
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDocumentDetailsDialog(BuildContext context, Document document) {
    showDialog(
      context: context,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    document.title,
                    style: GoogleFonts.cairo(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[800],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    document.description,
                    style: GoogleFonts.cairo(
                      fontSize: 16,
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildDocumentDetailRow('تاريخ الرفع:', document.uploadDate),
                  _buildDocumentDetailRow('حجم الملف:', document.fileSize),
                  _buildDocumentDetailRow('الحالة:', document.status),
                  _buildDocumentDetailRow('ملاحظات:', document.notes),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green[500],
                      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: Text(
                      'إغلاق',
                      style: GoogleFonts.cairo(
                        fontSize: 16,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDocumentDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Text(
            label,
            style: GoogleFonts.cairo(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            value,
            style: GoogleFonts.cairo(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEditableField(
      String label,
      IconData icon,
      TextEditingController controller,
      String? Function(String?) validator,
      ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.green[600], size: 22),
              const SizedBox(width: 12),
              Text(
                label,
                style: GoogleFonts.cairo(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _isEditing
              ? TextFormField(
            controller: controller,
            validator: validator,
            style: GoogleFonts.cairo(fontSize: 15, color: Colors.grey[700]),
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.grey[50],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.grey.shade200),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.grey.shade200),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.green.shade400),
              ),
              contentPadding: const EdgeInsets.all(16),
            ),
          )
              : Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Text(
              controller.text,
              style: GoogleFonts.cairo(
                fontSize: 15,
                color: Colors.grey[700],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildMenu(context),
          Image.asset(
            "assets/images/logo.png",
            height: 70,
            fit: BoxFit.contain,
          ),
        ],
      ),
    );
  }

  Widget _buildMenu(BuildContext context) {
    return PopupMenuButton<String>(
      icon: Icon(Icons.menu, size: 28, color: Colors.green[700]),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: Colors.green[700],
      elevation: 8,
      offset: const Offset(0, 40),
      itemBuilder: (BuildContext context) => [
        _buildMenuItem("الملف الشخصي", "profile", Icons.person),
        _buildMenuItem(
          "تقييم الطلبات الجديده",
          "evaluate_accounts",
          Icons.account_balance_wallet,
        ),
        _buildMenuItem(
          "طلبات المستفيدين المقبوله",
          "organize_shipments",
          Icons.receipt_long,
        ),
        _buildMenuItem("ادارة المتاجر", "market", Icons.shopping_cart),
        _buildMenuItem("تسجيل الخروج", "logout", Icons.logout),
      ],
      onSelected: (value) => _handleMenuSelection(context, value),
    );
  }

  void _handleMenuSelection(BuildContext context, String value) {
    final routes = {
      "evaluate_accounts": () => BeneficiaryEvaluationScreen(),
      "organize_shipments": () => ArrangeOrdersScreen(),
      "profile": () => ProfileScreenDetails(),
      "market": () => StoresManageScreen(),
    };

    if (routes.containsKey(value)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => routes[value]!()),
      );
    } else if (value == "logout") {
      showSignOutDialog(context);
    }
  }

  PopupMenuItem<String> _buildMenuItem(
      String text,
      String value,
      IconData icon,
      ) {
    return PopupMenuItem<String>(
      value: value,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              text,
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(width: 12),
            Icon(icon, color: Colors.white, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton(
      String text,
      Color color,
      IconData icon,
      VoidCallback onPressed,
      ) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        elevation: 2,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.white, size: 22),
          const SizedBox(width: 10),
          Text(
            text,
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  void _acceptOrder(OrderModelData order, String monthlyAmount, String status) {
    // Update the order status and monthly amount
    order.states = status;
    order.monthlyIncome = monthlyAmount;

    // Call the updateOrder method from OrderCubit
    context.read<OrderCubit>().updateOrder(order);
  }

  void _showApprovalDialog(BuildContext contextValue) {
    String selectedStatus = 'مقبول'; // Default selection
    TextEditingController amountController = TextEditingController();

    showDialog(
      context: contextValue,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl, // Ensure full RTL support
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title
                  Center(
                    child: Text(
                      'قبول الطلب',
                      style: GoogleFonts.cairo(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey[800],
                      ),
                      textAlign: TextAlign.right,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Monthly Amount Field
                  Text(
                    'أدخل المبلغ الشهري للمستفيد',
                    style: GoogleFonts.cairo(
                      fontSize: 16,
                      color: Colors.grey[700],
                    ),
                    textAlign: TextAlign.right,
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: amountController,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.right, // Align input text right
                    style: GoogleFonts.cairo(fontSize: 16),
                    decoration: InputDecoration(
                      hintText: '2000 ر.س', // Default hint
                      hintStyle: GoogleFonts.cairo(color: Colors.grey[400]),
                      filled: true,
                      fillColor: Colors.grey[50],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      contentPadding: const EdgeInsets.all(14),
                    ),
                  ),
                  const SizedBox(height: 16),

                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            if (amountController.text.isNotEmpty) {
                              Navigator.pop(context);
                              _acceptOrder(
                                widget.orderModelData, // Pass the order
                                amountController.text, // Pass the monthly amount
                                selectedStatus, // Pass the selected status
                              );
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'يرجى ملء جميع الحقول',
                                    style: GoogleFonts.cairo(),
                                    textAlign: TextAlign.right,
                                  ),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green.shade500,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                          child: Text(
                            'تأكيد',
                            style: GoogleFonts.cairo(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => Navigator.pop(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red.shade500,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                          child: Text(
                            'إلغاء',
                            style: GoogleFonts.cairo(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showRejectReasonDialog(BuildContext contextValue) {
    TextEditingController notificationController = TextEditingController();

    showDialog(
      context: contextValue,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl, // Ensure full RTL support
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title
                  Center(
                    child: Text(
                      'سبب رفض الطلب',
                      style: GoogleFonts.cairo(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey[800],
                      ),
                      textAlign: TextAlign.right,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Rejection Reason Field
                  Text(
                    'ادخل سبب رفض الطلب',
                    style: GoogleFonts.cairo(
                      fontSize: 16,
                      color: Colors.grey[700],
                    ),
                    textAlign: TextAlign.right,
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: notificationController,
                    keyboardType: TextInputType.text,
                    textAlign: TextAlign.right, // Align input text right
                    style: GoogleFonts.cairo(fontSize: 16),
                    decoration: InputDecoration(
                      hintText: 'حالة الطالب المادية لا تستدعي أي دخل اضافي!.',
                      hintStyle: GoogleFonts.cairo(
                        color: Colors.grey[400],
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          color: Colors.grey.shade300,
                        ),
                      ),
                      contentPadding: const EdgeInsets.all(14),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            if (notificationController.text.isNotEmpty) {
                              // Update the order status and rejection reason
                              widget.orderModelData.states = 'مرفوض';

                              // Call the updateOrder method from OrderCubit
                              contextValue.read<OrderCubit>().updateOrder(
                                widget.orderModelData,
                              );

                              Navigator.pop(context);
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'يرجى ملء جميع الحقول',
                                    style: GoogleFonts.cairo(),
                                    textAlign: TextAlign.right,
                                  ),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green.shade500,
                            padding: const EdgeInsets.symmetric(
                              vertical: 14,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                          child: Text(
                            'ارسال',
                            style: GoogleFonts.cairo(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => Navigator.pop(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red.shade500,
                            padding: const EdgeInsets.symmetric(
                              vertical: 14,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                          child: Text(
                            'إلغاء',
                            style: GoogleFonts.cairo(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}