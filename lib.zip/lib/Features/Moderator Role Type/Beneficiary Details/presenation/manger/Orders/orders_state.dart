import '../../../data/order_model.dart';

abstract class OrderState {}

class OrderInitial extends OrderState {}

class OrderLoading extends OrderState {}

class OrderLoaded extends OrderState {

  final List<OrderModelData> orders;

  OrderLoaded(this.orders);
}

class OrderEmpty extends OrderState {}

class OrderCreated extends OrderState {}

class OrderUpdated extends OrderState {}

class OrderDeleted extends OrderState {}

class OrderError extends OrderState {
  final String message;

  OrderError(this.message);
}