import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../data/order_model.dart';
import 'orders_state.dart';

class OrderCubit extends Cubit<OrderState> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  OrderCubit() : super(OrderInitial());

  void fetchOrders() async {
    emit(OrderLoading());
    try {
      final QuerySnapshot snapshot = await _firestore.collection('new_orders').get();
      if (snapshot.docs.isEmpty) {
        emit(OrderEmpty());
      } else {
        final List<OrderModelData> orders = snapshot.docs
            .map((doc) => OrderModelData.fromJson(doc.data() as Map<String, dynamic>))
            .toList();
        emit(OrderLoaded(orders));
      }
    } catch (e) {
      print(e.toString());
      emit(OrderError(e.toString()));
    }
  }

  // Create a new order
  void createOrder(OrderModelData order) async {
    emit(OrderLoading());
    try {
      await _firestore.collection('new_orders').doc().set(order.toJson());
      emit(OrderCreated());
      fetchOrders();
    } catch (e) {
      emit(OrderError(e.toString()));
    }
  }

  // Update an existing order
  void updateOrder(OrderModelData order) async {
    emit(OrderLoading());
    try {
      await _firestore.collection('new_orders').doc("CbZ0L7Qex5mpfmyiurNe").update(order.toJson());
      emit(OrderUpdated());
      fetchOrders();
    } catch (e) {
      print(e.toString());
      emit(OrderError(e.toString()));
    }
  }

  // Delete an order
  void deleteOrder(String orderId) async {
    emit(OrderLoading());
    try {
      await _firestore.collection('new_orders').doc(orderId).delete();
      emit(OrderDeleted());
      fetchOrders();
    } catch (e) {
      emit(OrderError(e.toString()));
    }
  }
}