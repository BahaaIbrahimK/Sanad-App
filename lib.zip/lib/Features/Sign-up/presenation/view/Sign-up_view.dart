import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sanad/Features/Sign-up/presenation/manger/sign_up_cubit.dart';
import 'package:sanad/core/Utils/Core%20Components.dart';

import '../../../Login/presenation/view/login_view.dart';

class RegisterScreen extends StatefulWidget {
  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  String accountType = 'مستفيد';
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _locationTitleController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => SignUpCubit(),
      child: BlocConsumer<SignUpCubit, SignUpState>(
        listener: (context, state) {
          if (state is SignUpAuthenticated) {
            // Show success message
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  accountType == 'متبرع'
                      ? "تم إنشاء حساب متبرع بنجاح"
                      : "تم إنشاء حساب مستفيد بنجاح",
                  style: GoogleFonts.cairo(),
                ),
                backgroundColor: Colors.green[700],
              ),
            );
            // Navigate to the login screen or home screen
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => LoginScreen()),
            );
          } else if (state is SignUpError) {
            // Show error message
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message, style: GoogleFonts.cairo()),
                backgroundColor: Colors.red,
              ),
            );
          }
        },
        builder: (context, state) {
          return Scaffold(
            backgroundColor: Colors.white,
            body: SafeArea(
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32.0),
                    child: SingleChildScrollView(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Logo
                            ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: Image.asset(
                                "assets/images/logo.png",
                                height: 70,
                                fit: BoxFit.cover,
                              ),
                            ),
                            const SizedBox(height: 20),

                            // Welcome message
                            Text(
                              "مرحبا بك في تطبيق سند\nيمكنك الآن الانضمام لدينا كمستفيد أو متبرع",
                              textAlign: TextAlign.center,
                              style: GoogleFonts.cairo(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 40),

                            // Full Name Field
                            _buildTextField(
                              label: "الإسم كاملاً :",
                              icon: Icons.person_outline,
                              isPassword: false,
                              controller: _fullNameController,
                              tooltip: "أدخل اسمك الكامل",
                            ),
                            const SizedBox(height: 20),

                            // Address Field
                            _buildTextField(
                              label: "عنوان السكن :",
                              icon: Icons.home_outlined,
                              isPassword: false,
                              controller: _locationTitleController,
                              tooltip: "أدخل عنوان سكنك",
                            ),
                            const SizedBox(height: 20),

                            // Phone Number Field
                            _buildTextField(
                              label: "رقم الهاتف :",
                              icon: Icons.phone_outlined,
                              isPassword: false,
                              keyboardType: TextInputType.phone,
                              controller: _phoneNumberController,
                              tooltip: "أدخل رقم هاتفك",
                            ),
                            const SizedBox(height: 20),

                            // Password Field
                            _buildTextField(
                              label: "كلمة المرور :",
                              icon: Icons.lock_outlined,
                              isPassword: true,
                              controller: _passwordController,
                              tooltip: "كلمة المرور يجب أن تكون على الأقل 6 أحرف",
                            ),
                            const SizedBox(height: 30),

                            // Account Type Radio Buttons
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "نوع الحساب :",
                                  style: GoogleFonts.cairo(
                                    fontSize: 16,
                                    color: Colors.black87,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: RadioListTile<String>(
                                        title: Text(
                                          'مستفيد',
                                          style: GoogleFonts.cairo(
                                            fontSize: 14,
                                            color: Colors.black87,
                                          ),
                                        ),
                                        value: 'مستفيد',
                                        groupValue: accountType,
                                        onChanged: (String? value) {
                                          setState(() {
                                            accountType = value!;
                                          });
                                        },
                                        activeColor: Colors.green[700],
                                      ),
                                    ),
                                    Expanded(
                                      child: RadioListTile<String>(
                                        title: Text(
                                          'متبرع',
                                          style: GoogleFonts.cairo(
                                            fontSize: 16,
                                            color: Colors.black87,
                                          ),
                                        ),
                                        value: 'متبرع',
                                        groupValue: accountType,
                                        onChanged: (String? value) {
                                          setState(() {
                                            accountType = value!;
                                          });
                                        },
                                        activeColor: Colors.green[700],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(height: 40),

                            // Register Button
                            state is SignUpLoading
                                ? LoadingWidget() // Show loading indicator
                                : ElevatedButton(
                              onPressed: () {
                                if (_formKey.currentState!.validate()) {
                                  // Call the signUp method from SignUpCubit
                                  context.read<SignUpCubit>().signUp(
                                    fullName: _fullNameController.text,
                                    locationTitle: _locationTitleController.text,
                                    phoneNumber: _phoneNumberController.text,
                                    password: _passwordController.text,
                                    userType: accountType,
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green[700],
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                padding: const EdgeInsets.symmetric(
                                    vertical: 16, horizontal: 50),
                                elevation: 5,
                                shadowColor: Colors.green.withOpacity(0.3),
                              ),
                              child: Text(
                                "أنشئ حساب",
                                style: GoogleFonts.cairo(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),

                            const SizedBox(height: 20),

                            // Login Button
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "هل تملك حساب بالفعل؟ ",
                                  style: GoogleFonts.cairo(
                                    fontSize: 15,
                                    color: Colors.black,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => LoginScreen(),
                                      ),
                                    );
                                  },
                                  child: Text(
                                    "تسجيل الدخول",
                                    style: GoogleFonts.cairo(
                                      fontSize: 15,
                                      color: Colors.green,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // Reusable TextField Widget
  Widget _buildTextField({
    required String label,
    required IconData icon,
    required bool isPassword,
    TextInputType keyboardType = TextInputType.text,
    TextEditingController? controller,
    String? tooltip,
  }) {
    return Tooltip(
      message: tooltip ?? "",
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 2,
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          obscureText: isPassword,
          style: GoogleFonts.cairo(color: Colors.black87),
          decoration: InputDecoration(
            prefixIcon: Icon(icon, color: Colors.grey[600]),
            hintText: label,
            hintStyle: GoogleFonts.cairo(color: Colors.grey[500]),
            filled: true,
            fillColor: Colors.grey[50],
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            contentPadding: const EdgeInsets.symmetric(
                vertical: 16, horizontal: 20),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'يرجى ملء هذا الحقل';
            }
            if (isPassword && value.length < 6) {
              return 'كلمة المرور يجب أن تكون على الأقل 6 أحرف';
            }
            if (keyboardType == TextInputType.phone && value.length != 10) {
              return 'رقم الهاتف يجب أن يكون 10 أرقام';
            }
            return null;
          },
        ),
      ),
    );
  }
}