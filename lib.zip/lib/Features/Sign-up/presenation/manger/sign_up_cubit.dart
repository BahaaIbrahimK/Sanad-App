import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:meta/meta.dart';

part 'sign_up_state.dart';

class SignUpCubit extends Cubit<SignUpState> {
  SignUpCubit() : super(SignUpInitial());

  // Sign up with email and password
  Future<void> signUp({
    required String fullName,
    required String locationTitle,
    required String phoneNumber,
    required String password,
    required String userType,
  }) async {
    emit(SignUpLoading());
    try {
      // Validate inputs
      if (fullName.isEmpty || locationTitle.isEmpty || phoneNumber.isEmpty || password.isEmpty || userType.isEmpty) {
        emit(SignUpError('All fields are required.'));
        return;
      }

      if (!RegExp(r"^\+?[0-9]{10,15}$").hasMatch(phoneNumber)) {
        emit(SignUpError('Please enter a valid phone number with country code.'));
        return;
      }

      if (password.length < 6) {
        emit(SignUpError('Password must be at least 6 characters long.'));
        return;
      }

      // Create user with Firebase Auth
      final userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: '$phoneNumber@example.com', // Use phone number as a placeholder email
        password: password,
      );

      // Save user details to Firestore
      await _saveUserDetails(
        fullName,
        locationTitle,
        phoneNumber,
        userType,
        userCredential.user!.uid, // Use the UID as the document ID
      );

      emit(SignUpAuthenticated(userCredential.user!));
    } on FirebaseAuthException catch (e) {
      emit(SignUpError(e.message ?? 'Sign-up failed. Please try again.'));
    } catch (e) {
      emit(SignUpError('An error occurred: $e'));
    }
  }

  // Save user details to Firestore
  Future<void> _saveUserDetails(
      String fullName,
      String locationTitle,
      String phoneNumber,
      String userType,
      String uid, // Use UID as the document ID
      ) async {
    await FirebaseFirestore.instance.collection('users').doc(uid).set({
      'fullName': fullName,
      'locationTitle': locationTitle,
      'phoneNumber': phoneNumber,
      'userType': userType,
    });
  }

  // Logout
  void logout() async {
    await FirebaseAuth.instance.signOut();
    emit(SignUpUnauthenticated());
  }
}