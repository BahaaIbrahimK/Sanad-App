import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sanad/Features/Login/presenation/view/login_view.dart';
import 'package:sanad/Features/Moderator%20Role%20Type/Beneficiary%20Details/presenation/manger/profile/profile_cubit.dart';
import 'Core/Utils/App Colors.dart';
import 'Features/Beneficiaries Role Type/Profile/presenation/view/Profile_view.dart';
import 'Features/Moderator Role Type/Beneficiary Details/presenation/view/ManageStoreScreen.dart';
import 'Features/Moderator Role Type/Beneficiary Details/presenation/view/profile_view.dart';
import 'bloc_observer.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  Bloc.observer = MyBlocObserver();

  Widget widget;

  runApp(MyApp(widget: LoginScreen()));
}

class MyApp extends StatelessWidget {
  final Widget widget;

  const MyApp({super.key, required this.widget});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ProfileCubit()..fetchUserData("niSy9QiK4OPL3EQRzaxwKLtHZu53"),
      child: MaterialApp(
          title: 'Flutter Demo',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            scaffoldBackgroundColor: AppColorsData.white,
            platform: TargetPlatform.iOS,
            primaryColor: AppColorsData.primarySwatch,
            canvasColor: Colors.transparent,
            fontFamily: "Urbanist",
            iconTheme: const IconThemeData(
                color: AppColorsData.primaryColor, size: 25),
            primarySwatch: Colors.orange,
            appBarTheme: const AppBarTheme(
              backgroundColor: AppColorsData.white,
              toolbarHeight: 50,
              elevation: 0,
              surfaceTintColor: AppColorsData.white,
              centerTitle: true,
            ),
          ),
          home: widget
      ),
    );
  }
}
